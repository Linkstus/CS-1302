package prob1;

public class RecursionExamples {

	public static void main(String[] args) {
		System.out.println("SumSeries: " + sumSeries(10));
		System.out.println("---------------------------");
		System.out.println("SumSeries: " + sumSeries(100));
		System.out.println("---------------------------");
		System.out.println("SumSeries: " + sumSeries(23));
		System.out.println("---------------------------");
		System.out.println("SumSeries: " + sumSeries(-10));
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		System.out.println("printReverse: ");
		printReverse("abcdefghijklmnopqrstuvwxyz",10);
		System.out.println("\n---------------------------");
		System.out.println("printReverse: ");
		printReverse("789456123",3);
		System.out.println("\n---------------------------");
		System.out.println("printReverse: ");
		printReverse("abcdefghijklmnopqrstuvwxyz",-1);
		System.out.println("\n---------------------------");
		System.out.println("printReverse2: ");
		printReverse2("abcdefghijklmnopqrstuvwxyz",10);
		System.out.println("\n---------------------------");
		System.out.println("printReverse2: ");
		printReverse2("789456123",3);
		System.out.println("\n---------------------------");
		System.out.println("printReverse2: ");
		printReverse2("abcdefghijklmnopqrstuvwxyz",-1);
		System.out.println("\n-----------------------------");
		System.out.println(countDigits("2a15963bc4",3,7));
		System.out.println("\n-----------------------------");
		System.out.println(countDigits("abc",2,5));
		System.out.println("\n-----------------------------");
		System.out.println(countDigits("2a15963bc4",-1,1));
		System.out.println("-------------------------------");
		System.out.println("countCode: " + countCode("acacac","ac"));
		System.out.println("-------------------------------");
		System.out.println("countCode: " + countCode("Dac12ac","ac"));
		System.out.println("-------------------------------");
		System.out.println("countCode: " + countCode("acacacac","ac"));
	}
	
	public static double sumSeries(int n) {
		if (n == 1) {
			return 1.0/n;
		}
		else if(n <= 0) {
			return 0;
		}
		else if (n % 2 == 0) {
			return (1.0/n) - sumSeries(n - 1);
		}
		else if(n % 2 != 0) {
			return (1.0/n) + sumSeries(n - 1);
		}
		else {
			return 0;
		}
	}

	public static void printReverse(String s, int n) {
		if(n <= 0) {
			System.out.println("the number needs to be a positive integer");
		}
		else if(s.length() > n) {
			System.out.print(s.substring(s.length()-n)); 
			printReverse(s.substring(0, s.length() - n), n);
		}
		else {
			System.out.print(s.substring(0));
		}
	}
	public static void printReverse2(String s, int n) {
		printReverse2(s, n, s.length()-1);
	}

	private static void printReverse2(String s, int n, int loc) {
		if(n <= 0) {
			System.out.println("the number needs to be a positive integer");
		}
		else if(s.length() > n) {
			System.out.print(s.substring(s.length()-n)); 
			printReverse2(s.substring(0, s.length() - n), n, loc - n);
		}
		else if(loc < n){
			System.out.print(s.substring(0));
		}
	}

	public static int countDigits(String s, int low, int high) {
		return countDigitsHelper(s, low, high, 0, 0);
	}
	
	public static int countDigitsHelper(String s, int low, int high, int pos, int count) {
		int temp = -1;
		if(low <= 0 || high <= 0) {
			return count;
		}
		if(pos < s.length() && Character.isDigit(s.charAt(pos))) {
			temp = Integer.parseInt(s.substring(pos, pos+1));
			if(temp >= low && temp <= high) {
				return countDigitsHelper(s, low, high, pos+1, count+1);
			}
			else {
				return countDigitsHelper(s, low, high, pos+1, count);
			}
		}
		else if(pos < s.length()){
			return countDigitsHelper(s, low, high, pos+1, count);
		}			
		else {
			return count;
		}
	}

	public static int countCode(String msg, String code ) {
		return countCode(msg, code, 0);
	}

	private static int countCode(String msg, String code, int pos ) {
		if(pos + code.length() < msg.length()) {
			String temp = msg.substring(pos, pos + code.length());
			if(temp.equals(code) ) {
				return 1 + countCode(msg, code, pos + code.length() + 1);
				
			}
			else {
				return countCode(msg, code, pos + 1);
			}
		}
		else {
			return 0;
		}
	}
}
