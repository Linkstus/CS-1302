package prob3;

public interface ITeleporter {
	
	public abstract String teleport(String dest);
	
}
