package prob3;

import java.util.ArrayList;
import java.util.Arrays;

public class MartianSortTester {

	public static void main(String[] args){
		Martian r1 = new RedMartian(1);
		Martian r2 = new RedMartian(2);
		Martian r3 = new RedMartian(3);
		Martian r4 = new RedMartian(4);
		Martian r5 = new RedMartian(5);
		Martian r6 = new RedMartian(6);
		Martian r7 = new RedMartian(7);
		Martian g1 = new GreenMartian(1);
		Martian g2 = new GreenMartian(2);
		Martian g3 = new GreenMartian(3);
		Martian g4 = new GreenMartian(4);
		Martian g5 = new GreenMartian(5);
		Martian g6 = new GreenMartian(6);
		Martian g7 = new GreenMartian(7);

		ArrayList<Martian> martians = new ArrayList<>(Arrays.asList(
				g5, g3, r2, g2, r3, g7, r5, r1, r7, g1, g4, r4, r6, g6 ));

		System.out.println("Original Order:");
		printMartianList(martians);
		selectionSortRecursive(martians);
		System.out.println("Sorted:");
		printMartianList(martians);

		martians = new ArrayList<>(Arrays.asList(
				r5, r1, r4, r3, r7, r2, r6, g1, g2, g3, g4, g5, g6, g7 ));

		System.out.println("Original Order:");
		printMartianList(martians);
		selectionSortRecursive(martians);
		System.out.println("Sorted:");
		printMartianList(martians);

		System.out.println("-------------------------------------------------------");
		r1 = new RedMartian(10);
		r2 = new RedMartian(9);
		r3 = new RedMartian(11);
		r4 = new RedMartian(19);
		r5 = new RedMartian(39);
		r6 = new RedMartian(0);
		r7 = new RedMartian(76);
		g1 = new GreenMartian(56);
		g2 = new GreenMartian(2);
		g3 = new GreenMartian(73);
		g4 = new GreenMartian(87);
		g5 = new GreenMartian(45);
		g6 = new GreenMartian(90);
		g7 = new GreenMartian(54);
		
		ArrayList<Martian> martians1 = new ArrayList<>(Arrays.asList(
				g5, g3, r2, g2, r3, g7, r5, r1, r7, g1, g4, r4, r6, g6 ));

		System.out.println("Original Order:");
		printMartianList(martians1);
		selectionSortRecursive(martians1);
		System.out.println("Sorted:");
		printMartianList(martians1);

		martians1 = new ArrayList<>(Arrays.asList(
				r5, r1, r4, r3, r7, r2, r6, g1, g2, g3, g4, g5, g6, g7 ));

		System.out.println("Original Order:");
		printMartianList(martians1);
		selectionSortRecursive(martians1);
		System.out.println("Sorted:");
		printMartianList(martians1);
	}

	public static void selectionSortRecursive(ArrayList<Martian> martians){
		if(martians.size() <= 1) {
			return;
		}
		int begPos = findFirstRedMartian(martians); 
		int endPos = findLastRedMartian(martians, begPos, martians.size() - 1);
		
		selectionSortRecursive(martians, begPos, endPos);
	}

	private static void selectionSortRecursive(ArrayList<Martian> martians, int begPos, int endPos){
		if(begPos < endPos) {
			int max = maxRedMartian(martians, endPos);
			swapRedMartians(martians, endPos, max);
			selectionSortRecursive(martians, begPos, findLastRedMartian(martians, begPos, endPos-1));
		}
		else {
			return ;
		}
	}
	
	private static int findFirstRedMartian(ArrayList<Martian> martians) {
		for(int i = 0; i < martians.size(); i++) {
			if(martians.get(i) instanceof RedMartian) {
				return i;
			}
		}
		return 0;
	}
	
	private static int findLastRedMartian(ArrayList<Martian> martians, int begPos, int endPos) {
		for(int i = endPos; i > begPos; i--) {
			if(martians.get(i) instanceof RedMartian) {
				return i;
			}
		}
		return 0;
	}
	
	private static int maxRedMartian(ArrayList<Martian> martians, int endPos) {
		RedMartian max = new RedMartian(0);
		int maxPos = 0;
		for(int i = 0; i <= endPos; i++) {
			if(martians.get(i) instanceof RedMartian) {
				if(martians.get(i).compareTo(max) > 0) {
					max = (RedMartian) martians.get(i);
					maxPos = i;
				}
			}
		}
		return maxPos;
	}
	
	private static void swapRedMartians(ArrayList<Martian> martians, int endPos, int maxPos) {
		if(maxPos == endPos) {
			return;
		}
		else {
			int temp = endPos;
			martians.add(endPos, martians.get(maxPos));
			martians.remove(maxPos);
			martians.add(maxPos, martians.get(temp));
			martians.remove(temp + 1);
		}
	}

	// Used for testing
	private static void printMartianList(ArrayList<Martian> martians) {
		StringBuilder sb = new StringBuilder();
		for(Martian m : martians) {
			if(m instanceof RedMartian)
				sb.append("R=");
			else
				sb.append("G=");
			sb.append(m.getId() + ", ");
		}
		sb.delete(sb.length()-2, sb.length());
		System.out.println(sb.toString());
	}
}
