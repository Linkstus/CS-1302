package prob2;

import java.util.ArrayList;

public class BinarySearchTester {

	public static int binarySearch( ArrayList<Blob> blobs, Blob bKey1, Blob bKey2 ) {
		return binarySearchHelper(blobs, 0, blobs.size(), bKey1, bKey2);
	}
	
	public static int binarySearchHelper(ArrayList<Blob> blobs, int low, int high, Blob bKey1, Blob bKey2) {
		int mid = low + (high - low) / 2;
		if(mid % 2 != 0) {
			mid -= 1;
		}
		int kCoolness = bKey1.getCoolnessFactor() + bKey2.getCoolnessFactor();
		int rCoolness = blobs.get(mid).getCoolnessFactor() + blobs.get(mid + 1).getCoolnessFactor();
		if(low < high) {
			if(rCoolness > kCoolness) {
				return binarySearchHelper(blobs, low, mid, bKey1, bKey2);
			}
			else if(rCoolness < kCoolness) {
				return binarySearchHelper(blobs, mid+2, high, bKey1, bKey2);
			}
			else {
				
				return mid;
			}
		}
		else {
			return -mid;
		}
	}

	public static void main( String[] args ) {
		// Sample code to create a sorted Blob list with 5 twins (10 elements).
		// You should make sure your code works with other numbers of twins.
		//testing of test
		ArrayList<Blob> blobs = buildBlobList(5);
		printBlobList(blobs);
		Blob b1 = new Blob(6);
		Blob b2 = new Blob(4);
		System.out.println(binarySearch(blobs, b1, b2));
		System.out.println("--------------------------------------");
		//test 2
		blobs.clear(); 
		blobs = buildBlobList(10);
		printBlobList(blobs);
		b1 = new Blob(9);
		b2 = new Blob(6);
		System.out.println(binarySearch(blobs, b1, b2));
		System.out.println("--------------------------------------");
		//test 3
		blobs.clear(); 
		blobs = buildBlobList(10);
		printBlobList(blobs);
		b1 = new Blob(11);
		b2 = new Blob(13);
		System.out.println(binarySearch(blobs, b1, b2));
		System.out.println("--------------------------------------");
		//test 4
		blobs.clear(); 
		blobs = buildBlobList(10);
		printBlobList(blobs);
		b1 = new Blob(-1);
		b2 = new Blob(0);
		System.out.println(binarySearch(blobs, b1, b2));
		System.out.println("--------------------------------------");
	}

	// You may use this method to build and return a sorted Blob
	// list based on sum of coolness factor for each of the twins.
	// Creates "numTwins" twins (i.e. 2*numTwins elements)
	private static ArrayList<Blob> buildBlobList(int numTwins) {
		ArrayList<Blob> blobs = new ArrayList<>();
		int cNess = 2;
		for(int i=1; i<=numTwins; i++) {
			Blob b1 = new Blob(cNess);
			cNess+=2;
			Blob b2 = new Blob(cNess--);
			blobs.add(b1);
			blobs.add(b2);
		}
		return blobs;
	}

	// You may use this method to print a blob list in a way that
	// emphasizes the twins and the sum of their coolness factors.
	private static void printBlobList(ArrayList<Blob> blobs) {
		StringBuilder sb = new StringBuilder("Sorted Blob list:\n");
		for(int i=0; i<blobs.size(); i+=2) {
			int cNess1 = blobs.get(i).getCoolnessFactor();
			int cNess2 = blobs.get(i+1).getCoolnessFactor();
			int twinPower = cNess1 + cNess2;
			sb.append(String.format("B(%d)+B(%d)=%d, ", cNess1, cNess2, twinPower));
		}
		sb.delete(sb.length()-2, sb.length());
		System.out.println(sb.toString());
	}
}
