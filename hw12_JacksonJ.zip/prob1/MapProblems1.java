package prob1;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeMap;

public class MapProblems1 {

	public static void main(String[] args) {
		
		TreeMap<Character, Integer> original = new TreeMap<>();
		original.put('A', 8);
		original.put('B', 2);
		original.put('C', 4);
		original.put('G', 2);
		original.put('L', 8);
		original.put('P', 2);
		original.put('R', 1);
		original.put('V', 3);
		
		TreeMap<Character, Integer> original2 = new TreeMap<>();
		original2.put('i', 11);
		original2.put('P', 6);
		original2.put('U', 8);
		original2.put('2', 14);
		original2.put('&', 19);
		original2.put('u', 16);
		original2.put('O', 8);
		original2.put('n', 11);
		
		System.out.println("Problem 1: ");
		System.out.println("Map before modifications: ");
		System.out.println(original.toString());
		System.out.println("Map after modifications: ");
		System.out.println(swapKeyValue(original));
		System.out.println("-----------------------------");
		System.out.println("Problem 1: ");
		System.out.println("Map before modifications: ");
		System.out.println(original2.toString());
		System.out.println("Map after modifications: ");
		System.out.println(swapKeyValue(original2));
		System.out.println("-----------------------------");
	}
	
	public static TreeMap<Integer, String> swapKeyValue(TreeMap<Character, Integer> swap) {
		TreeMap<Integer, String> returnMap = new TreeMap<>();
		Set<Character> key = swap.keySet();
		
		Iterator<Character> loop = key.iterator();
		
		while(loop.hasNext()) {
			char key1 = loop.next();
			int val1 = swap.get(key1);
			if(returnMap.containsKey(val1)) {
				returnMap.put(val1, "" + returnMap.get(val1) + key1);
			}
			else {
				returnMap.put(val1,  "" + key1);
			}
		}
		return returnMap;
	}
}
