package prob2;

import java.util.Comparator;

public class SalesComparator implements Comparator<Sales>{
	@Override
	public int compare(Sales s1, Sales s2) {
		double diffSale = s1.getSales() - s2.getSales();
		if(diffSale > 0) {
			return 1;
		}
		else if(diffSale < 0) {
			return -1;
		}
		else{
			int diffId = s1.getId() - s2.getId();

			if(diffId > 0){
				return 1;
			}

			else if(diffId < 0) {
				return -1;
			}

			else {
				int diffWeek = s1.getWeek() - s2.getWeek();
				if(diffWeek > 0) {
					return 1;
				}
				else if(diffWeek < 1) {
					return -1;
				}
				else {
					return 0;
				}
			}
		}
	}
}
