package prob2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapProblems2 {

	public static void main(String[] args) {
		HashMap<Integer, Double> week1 = new HashMap<>();
		week1.put(43, 100.10);
		week1.put(19, 200.50);
		week1.put(7, 300.25);
		week1.put(28, 110.00);
		
		HashMap<Integer, Double> week2 = new HashMap<>();
		week2.put(92, 200.00);
		week2.put(28, 190.00);
		week2.put(7, 100.75);
		week2.put(51, 200.25);
		week2.put(63, 100.10);
		
		HashMap<Integer, Double> week3 = new HashMap<>();
		week3.put(55, 2.7);
		week3.put(47, 8.99);
		week3.put(99, 10.1);
		week3.put(49, 1.11);
		
		HashMap<Integer, Double> week4 = new HashMap<>();
		week4.put(89, 12.12);
		week4.put(49, 990.73);
		week4.put(55, 4.87);
		week4.put(47, 33.22);
		week4.put(99, 63.9);
		
		System.out.println("Problem 1: ");
		System.out.println("Maps before modifications: ");
		System.out.println("Week1: " + week1.toString() + "\n" + "week2: " + week2.toString());
		System.out.println("Map after modifications: ");
		System.out.println(workedBoth(week1, week2));
		System.out.println("------------------------------------------------------------------");
		System.out.println("Problem 1: ");
		System.out.println("Maps before modifications: ");
		System.out.println("Week1: " + week3.toString() + "\n" + "week2: " + week4.toString());
		System.out.println("Map after modifications: ");
		System.out.println(workedBoth(week3, week4));
	  /*----------------------problem 2--------------*/
		
		HashMap<Integer, Double> week01 = new HashMap<>();
		week01.put(43, 100.10);
		week01.put(19, 200.50);
		week01.put(7, 300.25);
		week01.put(28, 110.00);
		
		HashMap<Integer, Double> week02 = new HashMap<>();
		week02.put(92, 200.00);
		week02.put(28, 190.00);
		week02.put(7, 100.75);
		week02.put(51, 200.25);
		week02.put(63, 100.10);
		
		HashMap<Integer, Double> week03 = new HashMap<>();
		week03.put(55, 2.7);
		week03.put(47, 8.99);
		week03.put(99, 10.1);
		week03.put(49, 1.11);
		
		HashMap<Integer, Double> week04 = new HashMap<>();
		week04.put(89, 12.12);
		week04.put(49, 990.73);
		week04.put(55, 4.87);
		week04.put(47, 33.22);
		week04.put(99, 63.9);
		
		System.out.println("Problem 2: ");
		System.out.println("Maps before modifications: ");
		System.out.println("Week1: " + week01.toString() + "\n" + "week2: " + week02.toString());
		System.out.println("Map after modifications: ");
		System.out.println(onlyWorkedOne(week01, week02));
		System.out.println("------------------------------------------------------------------");
		System.out.println("Problem 2: ");
		System.out.println("Maps before modifications: ");
		System.out.println("Week1: " + week03.toString() + "\n" + "week2: " + week04.toString());
		System.out.println("Map after modifications: ");
		System.out.println(onlyWorkedOne(week03, week04));
	  /*----------------------problem 2--------------*/
		
		ArrayList<HashMap<Integer, Double>> maps = new ArrayList<>();
		maps.add(week1);
		maps.add(week2);
		
		ArrayList<HashMap<Integer, Double>> maps2 = new ArrayList<>();
		maps2.add(week3);
		maps2.add(week4);
		maps2.add(week1);
		
		System.out.println("Problem 3: ");
		System.out.println("Maps before modifications: ");
		System.out.println("List of maps: " + maps2.toString());
		System.out.println("Map after modifications: ");
		System.out.println(sortSales(maps2));
		System.out.println("------------------------------------------------------------------");
	}
	
	public static Map<Integer, Double> workedBoth(HashMap<Integer, Double> week1, HashMap<Integer, Double> week2) {
		TreeMap<Integer, Double> returnMap = new TreeMap<>();
		
		Set<Integer> k1 = week1.keySet();
		Set<Integer> k2 = week2.keySet();
		
		Iterator<Integer> loop1 = k1.iterator();
		Iterator<Integer> loop2 = k2.iterator();
		
		while(loop1.hasNext()) {
			int key1 = loop1.next();
			while(loop2.hasNext()) {
				int key2 = loop2.next();
				if(key1 == key2) {
					returnMap.put(key1, week1.get(key1) + week2.get(key2));
				}
			}
			loop2 = k2.iterator();
		}
		return returnMap;
	}
	
	public static TreeMap<Integer, Double> onlyWorkedOne(HashMap<Integer, Double> week1, HashMap<Integer, Double> week2) {
		TreeMap<Integer, Double> returnMap = new TreeMap<>(week1);
		
		Set<Integer> k1 = week2.keySet();
		
		Iterator<Integer> loop1 = k1.iterator();
		
		while(loop1.hasNext()) {
			int key1 = loop1.next();
			if(returnMap.containsKey(key1)) {
				returnMap.remove(key1);
			}
			else {
				returnMap.put(key1, week2.get(key1));
			}
		}
		
		return returnMap;
	}
	
	public static List<Sales> sortSales(List<HashMap<Integer, Double>> weekSales) {
		ArrayList<Sales> sortedSales = new ArrayList<>();
		int i = 0;
		
		while(i < weekSales.size()) {
			HashMap<Integer, Double> week = weekSales.get(i);
			Set<Integer> key = week.keySet();
			Iterator<Integer> loop = key.iterator();
			
			while(loop.hasNext()) {
				int key1 = loop.next();
				Sales sales = new Sales(key1, week.get(key1), i+1);
				sortedSales.add(sales);
			}
			i++;
		}
		Collections.sort(sortedSales, new SalesComparator());
		return sortedSales;
	}
	
}
