package prob2;

public class Sales {
	protected int Id;
	protected double sales;
	protected int week;
	
	public Sales(int id, double sales, int week) {
		this.Id = id;
		this.sales = sales;
		this.week = week;
	}
	
	public int getId() {
		return Id;
	}
	
	public double getSales() {
		return sales;
	}
	
	public int getWeek() {
		return week;
	}
	
	public String toString() {
		return "sales=" + sales + ", id=" + Id + ", week=" + week;
	}
}
