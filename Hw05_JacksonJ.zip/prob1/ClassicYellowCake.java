package prob1;

public class ClassicYellowCake extends Cake{

	public ClassicYellowCake(String cakeMix) {
		super(cakeMix);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getLiquid() {
		// TODO Auto-generated method stub
		return "1 cup tab water";
	}

	@Override
	public String getOil() {
		// TODO Auto-generated method stub
		return "1/3 cup vegetable oil";
	}

	@Override
	public String getEggs() {
		// TODO Auto-generated method stub
		return "3 large eggs";
	}
	
	
}
