package prob1;

public class OrganicCake extends Cake{

	OrganicCake(String cakeMix){
		super(cakeMix);
	}

	@Override
	public String getLiquid() {
		// TODO Auto-generated method stub
		return "1 1/4 cup milk";
	}

	@Override
	public String getOil() {
		// TODO Auto-generated method stub
		return "1/2 cup canola oil";
	}

	@Override
	public String getEggs() {
		// TODO Auto-generated method stub
		return "2 large eggs";
	}
	
	
}
