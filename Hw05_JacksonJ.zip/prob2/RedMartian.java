package prob2;

public class RedMartian extends Martian{
	
	public RedMartian(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public String speak() {
		String s = String.format("id=%d, Rubldy Rock", super.getId());
		return s;
	}
	
	@Override
	public String toString() {
		String s = String.format("Red Martian - id=%d, vol=%d", super.getId(), super.getVolume());
		return s;
	}
}
