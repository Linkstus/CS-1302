package prob2;

public abstract class Martian implements Cloneable, Comparable<Martian>{
	private int id;
	private int volume;
	
	Martian(int id){
		this.id = id;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public int compareTo(Martian m) {
		// TODO Auto-generated method stub
		int diff = this.id - m.id;
		if(diff < 0) {
			return -1;
		}
		else if(diff > 0) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	@Override
	public boolean equals(Object o) {
		Martian m;
		if (o instanceof RedMartian) {
			m = (Martian) o;
			return this.id == m.id;
		}
		else if(o instanceof GreenMartian) {
			m = (Martian) o;
			return this.id == m.id;
		}
		else {
			return false;
		}
	}
	
	public int getId() {
		return id;
	}
	
	public int getVolume() {
		return volume;
	}
	
	public void setVolume(int level) {
		volume = level;
	}
	
	public abstract String speak();
	
	@Override
	public String toString() {
		String s = String.format("id=%d, vol= %d", getId(), getVolume());
		return s;
	}
	
	
}
