package prob2;

import java.util.ArrayList;
import java.util.Collections;

public class MartianManager implements Cloneable{

	private ArrayList<Martian> martians = new ArrayList<>();
	private ArrayList<GreenMartian> teleporters = new ArrayList<>();
	
	MartianManager(){	
	}
	
	public boolean addMartian(Martian m) {
		GreenMartian gm;
		if(martians.contains(m) == false) {
			martians.add(m);
			if(m instanceof GreenMartian) {
				gm = (GreenMartian) m;
				if(teleporters.contains(m) == false) {
					teleporters.add(gm);
				}
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	public String groupSpeak() {
		StringBuilder sb = new StringBuilder();
		RedMartian rm;
		GreenMartian gm;
		
		for(int i = 0; i < martians.size(); i++) {
			if(martians.get(i) instanceof RedMartian) {
				rm =(RedMartian) martians.get(i);
				sb.append("RedMartian: ");
				sb.append(rm.speak());
				sb.append("\n");
			}
			else{
				gm = (GreenMartian) martians.get(i);
				sb.append("GreenMartian: ");
				sb.append(gm.speak());
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	public String groupTeleport(String dest) {
		StringBuilder sb = new StringBuilder();
		GreenMartian gm;
		for(int i = 0; i < teleporters.size(); i++) {
			if(teleporters.get(i) instanceof GreenMartian) {
				gm = (GreenMartian) teleporters.get(i);
				sb.append("Teleporter: ");
				sb.append(gm.teleport(dest));
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	public int getNumMartians() {
		return martians.size();
	}
	
	public int getNumTeleporters() {
		return teleporters.size();
	}
	
	public Martian getMartianAt(int i) {
		if(i < 0 || i > martians.size() - 1) {
			return null;
		}
		else if(martians.get(i) != null) {
			return martians.get(i);
		}
		else {
			return null;
		}
	}
	
	public Teleporter getTeleporterAt(int i) {
		if(i < 0 || i > teleporters.size() - 1) {
			return null;
		}
		else if(teleporters.get(i) != null) {
			return teleporters.get(i);
		}
		else {
			return null;
		}
	}
	
	public Martian getMartianWithId(int id) {
		RedMartian rm = new RedMartian(id);
		if(martians.indexOf(rm) != -1){
			return martians.get(martians.indexOf(rm));
		}
		else {
			return null;
		}
	}
	
	public Martian getMartianClosestTo(int id) {
		ArrayList<Martian> m = new ArrayList<>();
		int diff = 999999999;
		
		for(int i = 0; i < martians.size(); i++) {
			if(diff > Math.abs(id - martians.get(i).getId())) {
				diff = Math.abs(id - martians.get(i).getId());
				m.clear();
				m.add(martians.get(i));
			}
			else if(diff < Math.abs(id - martians.get(i).getId())) {
				continue;
			}
		}
		if(m.get(0) instanceof RedMartian) {
			RedMartian rm = (RedMartian) m.get(0);
			return rm;
		}
		else {
			GreenMartian gm = (GreenMartian) m.get(0);
			return gm;
		}
	}
	
	public boolean removeMartian(int id) {
		GreenMartian gm = new GreenMartian(id);
		int posM = 0;
		int posT = 0;
		
		if(martians.indexOf(gm) == -1) {
			return false;
		}
		else {
			posM = martians.indexOf(gm);
			if(martians.get(posM) instanceof GreenMartian) {
				posT = teleporters.indexOf(gm);
				martians.remove(posM);
				teleporters.remove(posT);
				return true;
			}
			else {
				martians.remove(posM);
				return true;
			}
		}
	}
	
	public ArrayList<Martian> sortedMartians(){
		ArrayList<Martian> martiansC = new ArrayList<>();
		
		for(Martian m: martians) {
			martiansC.add(m);
		}
		
		Collections.sort(martiansC);
		
		return martiansC;
	}
	
	public void obliterateTeleporters() {
		GreenMartian gm = new GreenMartian(0);
		
		for(int i = teleporters.size()-1; i >= 0; i--) {
			gm = (GreenMartian) teleporters.get(i);
			martians.remove(gm);
			teleporters.remove(gm);
		}
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		MartianManager mmC = (MartianManager) super.clone();
		ArrayList<Martian> martiansC = (ArrayList<Martian>) martians.clone();
		ArrayList<GreenMartian> teleportersC = (ArrayList<GreenMartian>) teleporters.clone();
		mmC.martians = martiansC;
		mmC.teleporters = teleportersC;
		return mmC;
	}
	
}
