
package prob2;

import java.util.ArrayList;

public class MartianTester {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		
		MartianManager mm;
		mm = list();
		
		//Used to check to confirm that the .toString methods worked -- test01
		System.out.println("Testing toString methods: ");
		System.out.print("\n");
		stringTest();
		System.out.print("\n");
		
		
		//Used to test .equals methods on different elements -- test02
		System.out.println("Testing equals methods: ");
		System.out.print("\n");
		equalsTest();
		System.out.print("\n");
		
		
		//Used to test .compareTo method with different elements -- test03
		System.out.println("Testing comparison methods: ");
		System.out.print("\n");
		comparisonTest();
		System.out.print("\n");
		
		
		//Used to clone martians --test04
		System.out.println("Testing cloning method");
		cloningTest();
		System.out.println("\n");
		
		
		//Used to test MartianManger --test05
		System.out.println("Testing MartianManager methods: ");
		System.out.print("\n");
		managerTest();
		System.out.print("\n");
		
		
		//Used to test groupSpeak --test06
		System.out.println("Testing groupSpeak methods: ");
		System.out.print("\n");
		speakTest();
		System.out.print("\n");
		
		
		//Used to test groupTeleport --test07
		System.out.println("Testing groupTeleport methods: ");
		System.out.println("\n");
		teleportTest();
		System.out.println("\n");
		
		
		//Used to get martians at certain points --test08
		System.out.println("Testing getLocation methods: ");
		locationTest(mm);
		System.out.println("\n");
		
		
		//Used to get teleporters at certian points --test09
		System.out.println("Testing getTeleportLocation method: ");
		getTeleportLocationTest(mm);
		System.out.println("\n");
		
		
		//Used to get martians with certian id's--test10
		System.out.println("Testing getMartianWithId method");
		martianIdTest(mm);
		System.out.println("\n");
		
		
	    //Used to get closest martian to an id--test11
		System.out.println("Testing closestTo method");
		closestMartian(mm);
		System.out.println("\n");
		
		
		//Used to get closest martian to an id--test11
		System.out.println("Testing remove method");
		removeMartians(mm);
		System.out.println("\n");
		
		
		//Used to sort MartainManager array--test11
		System.out.println("Testing sort method");
		sortMartians(mm);
		System.out.println("\n");
		
		
		//Used to sort MartainManager array--test11
		System.out.println("Testing obliterateTeleporter method");
		killTeleporters(mm);
		System.out.println("\n");
		
		
		//Used to sort MartainManager array--test11
		System.out.println("Testing MartianMangerCloning method");
		cloningFaclity(mm);
		System.out.println("\n");
	}
	
	
	//Helper method to build a Arraylist
	public static MartianManager list(){
		MartianManager mm = new MartianManager();
		
		RedMartian rm1 = new RedMartian(35);
		GreenMartian gm1 = new GreenMartian(109384);
		GreenMartian gm2 = new GreenMartian(-200);
		RedMartian rm2 = new RedMartian(0);
		GreenMartian gm3 = new GreenMartian(35);
		GreenMartian gm4 = new GreenMartian(200);
		GreenMartian gm5 = new GreenMartian(100);
		GreenMartian gm6 = new GreenMartian(100);
		
		mm.addMartian(rm1);
		mm.addMartian(gm1);
		mm.addMartian(gm2);
		mm.addMartian(rm2);
		mm.addMartian(gm3);
		mm.addMartian(gm4);
		mm.addMartian(gm5);
		mm.addMartian(gm6);
		
		return mm;
	}
	
	public static void stringTest() {
		//Normal test
		try {
			RedMartian rm = new RedMartian(200);
			System.out.println("Normal test01 ");
			System.out.println("Expected result: RedMartian - id=200, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal test
		try {
			RedMartian rm1 = new RedMartian(100);
			System.out.println("\nNormal test02 ");
			System.out.println("Expected result: RedMartian - id=100, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm1.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal test
		try {
			RedMartian rm2 = new RedMartian(1);
			System.out.println("\nNormal test03 ");
			System.out.println("Expected result: RedMartian - id=1, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm2.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal test
		try {
			GreenMartian gm1 = new GreenMartian(50);
			System.out.println("\nNormal test04 ");
			System.out.println("Expected result: GreenMartian - id=50, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(gm1.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Extremely high value test
		try {
			GreenMartian gm2 = new GreenMartian(2147483647);
			System.out.println("\nExtemely high value test ");
			System.out.println("Expected result: GreenMartian - id=2147483647, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(gm2.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Extremely low value test
		try {
			RedMartian rm5 = new RedMartian(-2147483647);
			System.out.println("\nExtemely low value test ");
			System.out.println("Expected result: RedMartian - id=-2147483647, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm5.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Zero value test
		try {
			RedMartian rm5 = new RedMartian(0);
			System.out.println("\nZero value test ");
			System.out.println("Expected result: RedMartian - id=0, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm5.toString());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
	
	public static void equalsTest() {
		//Normal test 1
		try {
			RedMartian rm1 = new RedMartian(150);
			RedMartian rm2 = new RedMartian(150);
			System.out.println("Normal test01 ");
			System.out.println("Expected result: true ");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm1.equals(rm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal mixture test
		try {
			RedMartian rm2 = new RedMartian(35);
			GreenMartian gm1 = new GreenMartian(35);
			System.out.println("\nNormal different martian test01 ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm2.equals(gm1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal test
		try {
			RedMartian rm3 = new RedMartian(69);
			RedMartian rm4 = new RedMartian(25);
			System.out.println("\nNormal test03 ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm3.equals(rm4));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Normal mixture test
		try {
			RedMartian rm5 = new RedMartian(120);
			GreenMartian gm2 = new GreenMartian(139);
			System.out.println("\nNormal different martian test02 ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm5.equals(gm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//negative number with positive number test
		try {
			RedMartian rm6 = new RedMartian(-379);
			GreenMartian gm3 = new GreenMartian(379);
			System.out.println("\nNegative number with positive number ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm6.equals(gm3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//Testing zero value with other numbers
		try {
			RedMartian rm7 = new RedMartian(0);
			GreenMartian gm4 = new GreenMartian(30);
			System.out.println("\nTesting zero value with other numbers ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm7.equals(gm4));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		//same everything accept memory
		try {
			RedMartian rm8 = new RedMartian(23);
			GreenMartian gm5 = new GreenMartian(23);
			System.out.println("\nSame values ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm8.equals(gm5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
		
		//same reference in memory
		try {
			GreenMartian gm6 = new GreenMartian(500);
			GreenMartian gm7 = gm6;
			System.out.println("\nSame reference ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(gm6.equals(gm7));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}		
	}
	
	//Testing the comparison methods
	public static void comparisonTest() {
		//Normal test 1
		try {
			RedMartian rm1 = new RedMartian(150);
			RedMartian rm2 = new RedMartian(150);
			System.out.println("Normal test01 ");
			System.out.println("Expected result: 0 ");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm1.compareTo(rm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//Normal mixture test
		try {
			RedMartian rm2 = new RedMartian(35);
			GreenMartian gm1 = new GreenMartian(35);
			System.out.println("\nNormal different martian test01 ");
			System.out.println("Expected result: 0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm2.compareTo(gm1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//Normal test
		try {
			RedMartian rm3 = new RedMartian(69);
			RedMartian rm4 = new RedMartian(25);
			System.out.println("\nNormal test03 ");
			System.out.println("Expected result: 1");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm3.compareTo(rm4));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//Normal mixture test
		try {
			RedMartian rm5 = new RedMartian(120);
			GreenMartian gm2 = new GreenMartian(139);
			System.out.println("\nNormal different martian test02 ");
			System.out.println("Expected result: -1");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm5.compareTo(gm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		
		//negative number with negative number test
		try {
			RedMartian rm6 = new RedMartian(-379);
			GreenMartian gm3 = new GreenMartian(-379);
			System.out.println("\nNegative number with negative number ");
			System.out.println("Expected result: 0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm6.compareTo(gm3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
		
		
		//negative number with positive number test
		try {
			RedMartian rm6 = new RedMartian(-379);
			GreenMartian gm3 = new GreenMartian(379);
			System.out.println("\nNegative number with positive number ");
			System.out.println("Expected result: -1");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm6.compareTo(gm3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//Testing zero value with other numbers
		try {
			RedMartian rm7 = new RedMartian(0);
			GreenMartian gm4 = new GreenMartian(30);
			System.out.println("\nTesting zero value with other numbers ");
			System.out.println("Expected result: -1");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm7.compareTo(gm4));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//same everything accept memory
		try {
			RedMartian rm8 = new RedMartian(23);
			GreenMartian gm5 = new GreenMartian(23);
			System.out.println("\nSame values ");
			System.out.println("Expected result: 0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(rm8.compareTo(gm5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//same reference in memory
		try {
			GreenMartian gm6 = new GreenMartian(500);
			GreenMartian gm7 = gm6;
			System.out.println("\nSame reference ");
			System.out.println("Expected result: 0");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(gm6.compareTo(gm7));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
	
	
	//test the cloning facility
	public static void cloningTest() {
		RedMartian rm1 = new RedMartian(35);
		GreenMartian gm1 = new GreenMartian(109384);
		GreenMartian gm2 = new GreenMartian(-200);
		RedMartian rm2 = new RedMartian(0);
		GreenMartian gm3 = new GreenMartian(200);
		GreenMartian gm4 = new GreenMartian(100);
		
		//test 1
		try {
			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\nTesting 01 ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian one Original: RedMartian - id=35, vol=0"
					+ "\nRedMartian one Clone: RedMartian - id=35, vol=0"
					+ "\nGreenMartian one Origianl: GreenMartian - id=100, vol=0"
					+ "\nGreenMartian one Clone: GreenMartian - id=100, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.println("Actual Result: ");
			RedMartian rm1C = (RedMartian) rm1.clone();
			GreenMartian gm4C = (GreenMartian) gm4.clone();
			System.out.println("RedMartian one Original: " + rm1);
			System.out.println("RedMartian one Clone: " + rm1C);
			System.out.println("GreenMartian four Original: " + gm4);
			System.out.println("GreenMartian four Clone: " + gm4C);
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			RedMartian rm3 = new RedMartian(3876);
			System.out.print("\nTesting 02 ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian three Original: RedMartian - id=3876, vol=0"
					+ "\nRedMartian three Clone: RedMartian - id=3876, vol=0"
					+ "\nGreenMartian three Origianl: GreenMartian - id=200, vol=0"
					+ "\nGreenMartian three Clone: GreenMartian - id=200, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.println("Actual Result: ");
			RedMartian rm3C = (RedMartian) rm3.clone();
			GreenMartian gm3C = (GreenMartian) gm3.clone();
			System.out.println("RedMartian three Original: " + rm3);
			System.out.println("RedMartian three Clone: " + rm3C);
			System.out.println("GreenMartian Three Original: " + gm3);
			System.out.println("GreenMartian Three Clone: " + gm3C);
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm6 = new GreenMartian(2937);
			System.out.print("\nTesting 03 ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian two Original: GreenMartian - id=-200, vol=0"
					+ "\nGreenMartian two Clone: GreenMartian - id=-200, vol=0"
					+ "\nRedMartian two Origianl: RedMartian - id=0, vol=0"
					+ "\nRedMartian two Clone: RedMartian - id=0, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.println("Actual Result: ");
			RedMartian rm2C = (RedMartian) rm2.clone();
			GreenMartian gm2C = (GreenMartian) gm2.clone();
			System.out.println("GreenMartian three Original: " + gm2);
			System.out.println("GreenMartian three Clone: " + gm2C);
			System.out.println("RedMartian Three Original: " + rm2);
			System.out.println("RedMartian Three Clone: " + rm2C);
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			GreenMartian gm8 = new GreenMartian(2847);
			System.out.print("\nTesting 04 ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian one Original: GreenMartian - id=109384, vol=0"
					+ "\nGreenMartian one Clone: GreenMartian - id=109384, vol=0"
					+ "\nGreenMartian eight Origianl: GreenMartian - id=2847, vol=0"
					+ "\nGreenMartian eight Clone: GreenMartian - id=2847, vol=0");
			System.out.println("```````````````````````````````````````````");
			System.out.println("Actual Result: ");
			GreenMartian gm1C = (GreenMartian) gm1.clone();
			GreenMartian gm8C = (GreenMartian) gm8.clone();
			System.out.println("RedMartian one Original: " + gm1);
			System.out.println("RedMartian one Clone: " + gm1C);
			System.out.println("GreenMartian eight Original: " + gm8);
			System.out.println("GreenMartian eight Clone: " + gm8C);
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

	}

	
	//testing martian manager
	public static void managerTest() {
		MartianManager mm = new MartianManager();
		//test 1
		try {
			RedMartian rm1 = new RedMartian(150);
			System.out.println("Normal test ");
			System.out.println("RedMartian - id=150: ");
			System.out.println("Expected result: true ");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(rm1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			RedMartian rm2 = new RedMartian(35);
			System.out.println("\nNormal test ");
			System.out.println("RedMartian - id=35: ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(rm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			RedMartian rm3 = new RedMartian(69);
			System.out.println("\nNormal test ");
			System.out.println("RedMartian - id=69: ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(rm3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			RedMartian rm5 = new RedMartian(150);
			System.out.println("\nRepeat number ");
			System.out.println("\nRedMartian - id=150: ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(rm5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 5
		try {
			GreenMartian gm1 = new GreenMartian(-379);
			System.out.println("\nNegative number ");
			System.out.println("GreenMartian - id=-379: ");
			System.out.println("Expected result: true");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(gm1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}


		//test 6
		try {
			GreenMartian gm2 = new GreenMartian(-379);
			System.out.println("\nRepeat number ");
			System.out.println("GreenMartian - id=-379: ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(gm2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 7
		try {
			GreenMartian gm4 = new GreenMartian(69);
			System.out.println("\nRepeat number ");
			System.out.println("GreenMartian - id=69: ");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(gm4));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 8
		try {
			GreenMartian gm5 = new GreenMartian(35);
			System.out.println("\nRepeat number ");
			System.out.println("GreenMartian - id=35:");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(gm5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 9
		try {
			GreenMartian gm6 = new GreenMartian(150);
			GreenMartian gm7 = gm6;
			System.out.println("\nSame memory ");
			System.out.println("GreenMartian - id=150:");
			System.out.println("Expected result: false");
			System.out.println("```````````````````````````````````````````");
			System.out.print("Actual Result: ");
			System.out.println(mm.addMartian(gm7));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
	
	//testing groupSpeak
	public static void speakTest() {
		MartianManager mm = new MartianManager();
		//test 1
		try {
			RedMartian rm1 = new RedMartian(150);
			System.out.print("RedMartian ");
			System.out.println("Expected result: "
					+ "\nRedMartian - id=150, Rubldy Rock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm1);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			RedMartian rm2 = new RedMartian(35);
			System.out.print("\nRedMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm2);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			RedMartian rm3 = new RedMartian(69);
			System.out.print("\nRedMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm3);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			RedMartian rm5 = new RedMartian(187);
			System.out.print("\nRedMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm5);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 5
		try {
			GreenMartian gm1 = new GreenMartian(-379);
			System.out.print("\nGreenMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock"
					+ "\nGreenMartian - id=-379, Grobldy Grock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm1);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 6
		try {
			GreenMartian gm2 = new GreenMartian(3876);
			System.out.print("\nGreenMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock"
					+ "\nGreenMartian - id=-379, Grobldy Grock"
					+ "\nGreenMartian - id=3876, Grobldy Grock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm2);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 7
		try {
			GreenMartian gm4 = new GreenMartian(2937);
			System.out.print("\nGreenMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock"
					+ "\nGreenMartian - id=-379, Grobldy Grock"
					+ "\nGreenMartian - id=3876, Grobldy Grock"
					+ "\nGreenMartian - id=2937, Grobldy Grock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm4);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 8
		try {
			GreenMartian gm5 = new GreenMartian(2847);
			System.out.print("\nGreenMartian");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock"
					+ "\nGreenMartian - id=-379, Grobldy Grock"
					+ "\nGreenMartian - id=3876, Grobldy Grock"
					+ "\nGreenMartian - id=2937, Grobldy Grock"
					+ "\nGreenMartian - id=2847, Grobldy Grock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 9
		try {
			GreenMartian gm6 = new GreenMartian(409);
			System.out.print("\nGreenMartian ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=150, Rubldy Rock"
					+ "\nRedMartian - id=35, Rubldy Rock"
					+ "\nRedMartian - id=69, Rubldy Rock"
					+ "\nRedMartian - id=187, Rubldy Rock"
					+ "\nGreenMartian - id=-379, Grobldy Grock"
					+ "\nGreenMartian - id=3876, Grobldy Grock"
					+ "\nGreenMartian - id=2937, Grobldy Grock"
					+ "\nGreenMartian - id=2847, Grobldy Grock"
					+ "\nGreenMartian - id=409, Grobldy Grock");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupSpeak());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
	
	
	//testing groupSpeak
	public static void teleportTest() {
		MartianManager mm = new MartianManager();

		//test 1
		try {
			GreenMartian gm1 = new GreenMartian(-379);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Valdosta");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm1);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Valdosta"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm2 = new GreenMartian(3876);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Las Vegas"
					+ "\nTeleport: id=3876 teleporting to Las Vegas");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm2);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Las Vegas"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm3 = new GreenMartian(2937);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Tronto"
					+ "\nTeleport: id=3876 teleporting to Tronto"
					+ "\nTeleport: id=2937 teleporting to Tronto");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm3);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Tronto"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			GreenMartian gm4 = new GreenMartian(2847);
			System.out.print("\nNormal testing");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to HollyWood"  
					+ "\nTeleport: id=3876 teleporting to HollyWood"  
					+ "\nTeleport: id=2937 teleporting to HollyWood"
					+ "\nTeleport: id=2847 teleporting to HollyWood");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm4);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("HollyWood"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm5 = new GreenMartian(409);
			System.out.print("\nNumber string ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Galaxy 00110"  
					+ "\nTeleport: id=3876 teleporting to Galaxy 00110"  
					+ "\nTeleport: id=2937 teleporting to Galaxy 00110"
					+ "\nTeleport: id=2847 teleporting to Galaxy 00110"
					+ "\nTeleport: id=409 teleporting to Galaxy 00110");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Galaxy 00110"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
		
		//test 6
		try {
			GreenMartian gm6 = new GreenMartian(69);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Paris"  
					+ "\nTeleport: id=3876 teleporting to Paris"  
					+ "\nTeleport: id=2937 teleporting to Paris"
					+ "\nTeleport: id=2847 teleporting to Paris"
					+ "\nTeleport: id=409 teleporting to Paris"
					+ "\nTeleport: id=69 teleporting to Paris");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Paris"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 7
		try {
			GreenMartian gm7 = new GreenMartian(187);
			System.out.print("\nBlank Testing");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to "  
					+ "\nTeleport: id=3876 teleporting to "  
					+ "\nTeleport: id=2937 teleporting to "
					+ "\nTeleport: id=2847 teleporting to "
					+ "\nTeleport: id=409 teleporting to "
					+ "\nTeleport: id=69 teleporting to "
					+ "\nTeleport: id=187 teleporting to ");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport(""));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 8
		try {
			GreenMartian gm8 = new GreenMartian(379);
			System.out.print("\nNormal Testing ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Mars"  
					+ "\nTeleport: id=3876 teleporting to Mars"  
					+ "\nTeleport: id=2937 teleporting to Mars"
					+ "\nTeleport: id=2847 teleporting to Mars"
					+ "\nTeleport: id=409 teleporting to Mars"
					+ "\nTeleport: id=69 teleporting to Mars"
					+ "\nTeleport: id=187 teleporting to Mars"
					+ "\nTeleport: id=379 teleporting to Mars");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm8);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Mars"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 9
		try {
			RedMartian rm1 = new RedMartian(897);
			System.out.print("\nRedMartian test ");
			System.out.println("\nExpected result: "
					+ "\nTeleport: id=-379 teleporting to Valdosta"  
					+ "\nTeleport: id=3876 teleporting to Valdosta"  
					+ "\nTeleport: id=2937 teleporting to Valdosta"
					+ "\nTeleport: id=2847 teleporting to Vldosta"
					+ "\nTeleport: id=409 teleporting to Valdosta"
					+ "\nTeleport: id=69 teleporting to Valdosta"
					+ "\nTeleport: id=187 teleporting to Valdosta"
					+ "\nTeleport: id=-379 teleporting to Valdosta");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm1);
			System.out.println("Actual Result: ");
			System.out.print(mm.groupTeleport("Valdosta"));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	
	//test the get martain at certain location
	public static void locationTest(MartianManager mm) {

		//test 1
		try {
			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=-200, vol=0"
					+ "\nGreenMartian - id= -379, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(2));
			System.out.println(mm.getMartianAt(6));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=0, vol=0"
					+ "\nGreenMartian - id=3876, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(3));
			System.out.println(mm.getMartianAt(7));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\nHigh limit ");
			System.out.println("\nExpected result: "
					+ "\nnull"
					+ "\nGreenMartian - id=100, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(10));
			System.out.println(mm.getMartianAt(5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			GreenMartian gm8 = new GreenMartian(2847);
			System.out.print("\nLow bounds");
			System.out.println("\nExpected result: "
					+ "\nnull"
					+ "\nRedMartian - id=0, vol=0"
					+ "\nnull");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm8);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(78));
			System.out.println(mm.getMartianAt(3));
			System.out.println(mm.getMartianAt(-8));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm9 = new GreenMartian(409);
			System.out.print("\nLocation zero ");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=35, vol=0"
					+ "\nnull"
					+ "\nGreenMartian - id=2847, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm9);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(0));
			System.out.println(mm.getMartianAt(98));
			System.out.println(mm.getMartianAt(9));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
		
	
	//test the get teleport martians at certain location
	public static void getTeleportLocationTest(MartianManager mm) {
		//test 1
		try {
			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=200, vol=0"
					+ "\nGreenMartian - id=100, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.getTeleporterAt(2));
			System.out.println(mm.getTeleporterAt(3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=109384, vol=0"
					+ "\nGreenMartian - id=3876, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.getTeleporterAt(0));
			System.out.println(mm.getTeleporterAt(5));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\nHigh limit ");
			System.out.println("\nExpected result: "
					+ "\nnull"
					+ "\nGreenMartian - id=200, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.getTeleporterAt(7));
			System.out.println(mm.getTeleporterAt(2));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			GreenMartian gm8 = new GreenMartian(2847);
			System.out.print("\nLow bounds");
			System.out.println("\nExpected result: "
					+ "\nnull"
					+ "\nGreenMartian - id=2937, vol=0"
					+ "\nnull");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm8);
			System.out.println("Actual Result: ");
			System.out.println(mm.getTeleporterAt(78));
			System.out.println(mm.getTeleporterAt(6));
			System.out.println(mm.getTeleporterAt(-8));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm9 = new GreenMartian(409);
			System.out.print("\nLocation zero ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=109384, vol=0"
					+ "\nnull"
					+ "\nGreenMartian - id=100, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm9);
			System.out.println("Actual Result: ");
			System.out.println(mm.getTeleporterAt(0));
			System.out.println(mm.getTeleporterAt(10));
			System.out.println(mm.getTeleporterAt(3));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
	}
	
	
	//test the get specific martian with id
	public static void martianIdTest(MartianManager mm) {
		//test 1
		try {
			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=200, vol=0"
					+ "\nRedMartian - id=35, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianWithId(200));
			System.out.println(mm.getMartianWithId(35));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=379, vol=0"
					+ "\nGreenMartian - id=109384, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianWithId(379));
			System.out.println(mm.getMartianWithId(109384));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\nExtemely high Id ");
			System.out.println("\nExpected result: "
					+ "\nnull"
					+ "\nRedMartian - id=35, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianWithId(273947564));
			System.out.println(mm.getMartianWithId(35));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			Martian rm3 = new RedMartian(2847);
			System.out.print("\nExtremely low Id");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=100, vol=0"
					+ "\nRedMartian - id=0, vol=0"
					+ "\nnull");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm3);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianWithId(100));
			System.out.println(mm.getMartianWithId(3));
			System.out.println(mm.getMartianWithId(-273947564));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm9 = new GreenMartian(409);
			System.out.print("\nZero Id");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=35, vol=0"
					+ "\nnull"
					+ "\nGreenMartian - id=2847, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm9);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(0));
			System.out.println(mm.getMartianAt(98));
			System.out.println(mm.getMartianAt(9));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	
		
		//test 6
		try {
			GreenMartian gm10 = new GreenMartian(5896);
			System.out.print("\nNegative id");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=-200, vol=0"
					+ "\nnull"
					+ "\nGreenMartian - id=2847, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm10);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianAt(-200));
			System.out.println(mm.getMartianAt(98));
			System.out.println(mm.getMartianAt(9));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	
	//test the get a close martian to the give id;
	public static void closestMartian(MartianManager mm) {
		//test 1
		try {

			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=200, vol=0"
					+ "\nRedMartian - id=35, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianClosestTo(195));
			System.out.println(mm.getMartianClosestTo(30));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\nNormal testing ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=200, vol=0"
					+ "\nRedMartian - id=0, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianClosestTo(2000));
			System.out.println(mm.getMartianClosestTo(1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\nExtemely high Id ");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=2937, vol=0"
					+ "\nGreenMartian - id=200, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianClosestTo(9999));
			System.out.println(mm.getMartianClosestTo(500));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			Martian rm3 = new RedMartian(2847);
			System.out.print("\nNegative Ids");
			System.out.println("\nExpected result: "
					+ "\nGreenMartian - id=-379, vol=0"
					+ "\nRedMartian - id=0, vol=0"
					+ "\nGreenMartian - id=200, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm3);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianClosestTo(-2000));
			System.out.println(mm.getMartianClosestTo(-34));
			System.out.println(mm.getMartianClosestTo(243));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm9 = new GreenMartian(409);
			System.out.print("\nZero Id");
			System.out.println("\nExpected result: "
					+ "\nRedMartian - id=0, vol=0"
					+ "\nGreenMartian - id=109384, vol=0"
					+ "\nGreenMartian - id=3876, vol=0");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm9);
			System.out.println("Actual Result: ");
			System.out.println(mm.getMartianClosestTo(0));
			System.out.println(mm.getMartianClosestTo(100000));
			System.out.println(mm.getMartianClosestTo(5000));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	
	//test the remove a martian at an id;
	public static void removeMartians(MartianManager mm) {
		//test 1
		try {

			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\ntest 1");
			System.out.println("\nExpected result: "
					+ "\ntrue"
					+ "\nfalse");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.removeMartian(109384));
			System.out.println(mm.removeMartian(-1));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\ntest 2 ");
			System.out.println("\nExpected result: "
					+ "\nfalse"
					+ "\ntrue");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.removeMartian(1000));
			System.out.println(mm.removeMartian(-200));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\ntest 3 ");
			System.out.println("\nExpected result: "
					+ "\nfalse"
					+ "\ntrue");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.removeMartian(9999));
			System.out.println(mm.removeMartian(35));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 4
		try {
			RedMartian rm3 = new RedMartian(2847);
			System.out.print("\ntest 4");
			System.out.println("\nExpected result: "
					+ "\ntrue"
					+ "\nfalse"
					+ "\ntrue");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(rm3);
			System.out.println("Actual Result: ");
			System.out.println(mm.removeMartian(2847));
			System.out.println(mm.removeMartian(-250));
			System.out.println(mm.removeMartian(200));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}	

		//test 5
		try {
			GreenMartian gm9 = new GreenMartian(409);
			System.out.print("\ntest 5");
			System.out.println("\nExpected result: "
					+ "\ntrue"
					+ "\ntrue"
					+ "\ntrue");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm9);
			System.out.println("Actual Result: ");
			System.out.println(mm.removeMartian(0));
			System.out.println(mm.removeMartian(409));
			System.out.println(mm.removeMartian(100));
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	
	//test the sort martians method;
	public static void sortMartians(MartianManager mm) {
		//test 1
		try {

			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\ntest 1");
			System.out.println("\nExpected result: "
					+ "\n[Green Martian - id=-379, vol=0, Green Martian - id=-200, vol=0, "
					+ "Red Martian - id=0, vol=0, "
					+ "Red Martian - id=35, vol=0, "
					+ "Green Martian - id=100, vol=0, "
					+ "Green Martian - id=200, vol=0, "
					+ "Green Martian - id=109384, vol=0]");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			System.out.println(mm.sortedMartians());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\ntest 2 ");
			System.out.println("\nExpected result: "
					+ "\n[Green Martian - id=-379, vol=0, Green Martian - id=-200, vol=0, "  
					+"Red Martian - id=0, vol=0, " 
					+"Red Martian - id=35, vol=0, " 
					+"Green Martian - id=100, vol=0, " 
					+"Green Martian - id=200, vol=0, "
					+"Green Martian - id=3876, vol=0, " 
					+"Green Martian - id=109384, vol=0]");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			System.out.println(mm.sortedMartians());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(2937);
			System.out.print("\ntest 3 ");
			System.out.println("\nExpected result: "
					+ "\n[Green Martian - id=-379, vol=0, Green Martian - id=-200, vol=0, "  
					+"Red Martian - id=0, vol=0, " 
					+"Red Martian - id=35, vol=0, " 
					+"Green Martian - id=100, vol=0, " 
					+"Green Martian - id=200, vol=0, "
					+ "Green Martian - id=2937, vol=0, "
					+"Green Martian - id=3876, vol=0, " 
					+"Green Martian - id=109384, vol=0]");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			System.out.println(mm.sortedMartians());
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	//test remove teleporters and greenMartians method;
	public static void killTeleporters(MartianManager mm) {
		//test 1
		try {

			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\ntest 1");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			mm.obliterateTeleporters();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\ntest 2 ");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			mm.obliterateTeleporters();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(-65432);
			System.out.print("\ntest 3 ");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			mm.obliterateTeleporters();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
	
	
	//test MartianManger cloningmethod;
	public static void cloningFaclity(MartianManager mm) {
		//test 1
		try {

			GreenMartian gm5 = new GreenMartian(-379);
			System.out.print("\ntest 1");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm5);
			System.out.println("Actual Result: ");
			mm.clone();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 2
		try {
			GreenMartian gm6 = new GreenMartian(3876);
			System.out.print("\ntest 2 ");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm6);
			System.out.println("Actual Result: ");
			mm.clone();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}

		//test 3
		try {
			GreenMartian gm7 = new GreenMartian(-65432);
			System.out.print("\ntest 3 ");
			System.out.println("\nExpected result: "
					+ "\n");
			System.out.println("```````````````````````````````````````````");
			mm.addMartian(gm7);
			System.out.println("Actual Result: ");
			mm.clone();
			System.out.println("-------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Error!");
		}
	}
}
