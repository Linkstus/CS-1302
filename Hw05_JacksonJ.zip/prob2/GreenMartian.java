package prob2;

public class GreenMartian extends Martian implements Teleporter{

	GreenMartian(int id){
		super(id);
	}
	
	public String speak() {
		String s = String.format("id=%d, Grobldy Grock", super.getId());
		return s;
	}
	
	public String teleport(String dest) {
		String s = String.format("id=%d teleporting to %s", super.getId(), dest);
		return s;
	}
	
	@Override
	public String toString() {
		String s = String.format("Green Martian - id=%d, vol=%d", super.getId(), super.getVolume());
		return s;
	}
}
