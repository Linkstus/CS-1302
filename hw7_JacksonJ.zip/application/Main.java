package application;
	
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import martian_stuff.*;


public class Main extends Application {
	protected BorderPane bpGraph = new BorderPane();
	protected HBox hbxRadioButton = new HBox();
	protected ComboBox<String> cmbSelect = new ComboBox<>();
	protected ComboBox<String> cmbMartians = new ComboBox<>();
	protected VBox vbGT = new VBox();
	protected RadioButton addR = new RadioButton();
	protected RadioButton addG = new RadioButton(); 
	protected RadioButton addB = new RadioButton();
	protected RadioButton bar = new RadioButton();
	protected RadioButton pie = new RadioButton();
	protected ToggleGroup martians = new ToggleGroup();
	protected ToggleGroup graph = new ToggleGroup();
	protected TextField tfRed = new TextField();
	protected TextField tfGreen = new TextField();
	protected TextField volume = new TextField("Volume");
	protected Label lbRM = new Label();
	protected Label lbGM = new Label(); 
	protected Label lbMinN = new Label();
	protected Label lbMaxN = new Label();
	protected Label lbSelect = new Label();
	protected Label lbDisplay = new Label();
	protected Label lbVolume = new Label();
	protected Label lbtVolume = new Label();
	protected TextArea txaD = new TextArea();
	protected Button addButton = new Button();
	protected Button readButton = new Button();
	protected Button writeFromListButton = new Button();
	protected Button displayAllMartians = new Button();
	protected Button Obliterate = new Button();
	protected Button refreshC = new Button();
	protected MartianManager mm = new MartianManager();
	protected Slider sVolume = new Slider();
	protected TabPane tabPane = new TabPane();
	protected Tab main = new Tab();
	protected Tab graphs = new Tab();
	protected CheckBox cbGraph1 = new CheckBox();
	protected CheckBox cbGraph2 = new CheckBox();
	protected CategoryAxis xAxis = new CategoryAxis();
	protected NumberAxis yAxis = new NumberAxis();
	protected BarChart bgVolume = new BarChart(xAxis, yAxis);
	protected XYChart.Series data = new XYChart.Series();
	protected ArrayList<Martian> MM = new ArrayList<>();
	protected MartianEventHandler radioControlEventHandler = new MartianEventHandler();
	protected CheckBox esp = new CheckBox("hasEsp");
	protected CheckBox veg = new CheckBox("isVegetarian");
	protected RedMartian rm;
	protected GreenMartian gm;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane root = buildTabbedGui();
			Scene scene = new Scene(root,700,500);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("HomeWork_7-JacksonJ");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//Builds the Tab portion of the frame
		public Pane buildTabbedGui() {
			BorderPane bpMainFrame = new BorderPane();
			TabPane tabPane = new TabPane();
			
			tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
			
			Tab main = new Tab("Main");
			main.setContent(buildMainWindow());
			
			Tab graph = new Tab("graph");
			graph.setContent(buildGraph());
			tabPane.getTabs().addAll(main, graph);
			
			bpMainFrame.setTop(tabPane);
			return bpMainFrame;
			
		}
		
		//builds the stuff in the first tab
		public BorderPane buildMainWindow() {
			BorderPane bpMain = new BorderPane();
			
			bpMain.setTop(buildTopRow());
			bpMain.setLeft(buildLeft());
			bpMain.setCenter(buildCenter());
			bpMain.setRight(buildRight());
			bpMain.setBottom(buildBottom());

			return bpMain;
		}
		
	//brings other frames into the main window without the duplicate frame add error
	public void otherFrames(String select) {
		if(select.equals("Group Teleport")) {
			teleportTextField();
		}
		else if(select.equals("Retrive specific Martian")) {
			retrieveAMartian();
		}
		else if(select.equals("Remove specific Martian")) {
			removeAMartian();
		}
		else if(select.equals("Change Martian Volume")) {
			changeMartianVolume();
		}
	}
	
	//builds the options combo box
	public HBox buildTopRow() {
		HBox hbxSelect = new HBox();
		Label lbSelect = new Label("Select options:");
		
		hbxSelect.getChildren().addAll(lbSelect, buildComboBox());
		
		return hbxSelect;
	}
	
	//builds the area for radio Buttons
	public VBox buildLeft() {
		VBox vbxSelectMartian = new VBox();
		
		lbSelect.setText("Select Martian");
		vbxSelectMartian.getChildren().addAll(lbSelect, addBoth(), addRed(), addGreen()/*, martianComboBox()*/);
		vbxSelectMartian.setId("selectMartian");
		
		return vbxSelectMartian;

	}
	
	//Builds the center frame
	public GridPane buildCenter() {
		GridPane gpCenter = new GridPane();
		
		lbMinN.setText("Min id number:         " + Integer.MIN_VALUE);
		lbMaxN.setText("Max id number:         " + Integer.MAX_VALUE);
		
		lbRM.setText("Red Martian id");
		lbGM.setText("Green Martian id");
		
		gpCenter.add(lbRM, 1, 2);
		gpCenter.add(tfRed, 1, 3);
		
		gpCenter.add(lbMinN, 1, 4);
		gpCenter.add(lbMaxN, 1, 5);
		
		gpCenter.add(lbGM, 1, 6);
		gpCenter.add(tfGreen, 1, 7);
		
		if(addB.isSelected()) {
			gpCenter.add(esp, 3, 5);
			gpCenter.add(veg, 3, 6);
			esp.setVisible(false);
			veg.setVisible(false);
		}
		if(addB.isSelected()) {
			gpCenter.add(lbtVolume, 3, 3);
			gpCenter.add(volume, 3, 3);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
		else {
			volume.setVisible(false);
			lbtVolume.setVisible(true);
		}
		/*lbDisplay.setText("Display A Martian");
		gpCenter.add(lbDisplay, 2, 4);*/
		lbVolume.setText("Change Martian Volume");
		gpCenter.add(lbVolume, 2, 4);
		gpCenter.add(sVolume, 2, 5);
		sVolume.setVisible(false);
		lbVolume.setVisible(false);
		
		return gpCenter; 

	}

	//builds the pane and text area for displaying text
	public VBox buildBottom() {
		VBox vbxDisplay = new VBox();
		Label lbD = new Label("Display Box");
		txaD.setEditable(false);
		
		vbxDisplay.getChildren().addAll(lbD, txaD);
		
		return vbxDisplay;
	}
	
	//builds the button area
	public VBox buildRight() {
		VBox vbxButtons = new VBox();
		
		vbxButtons.getChildren().addAll(addButton(), readButton(), writeFromListButton(), displayAllMartians());
		vbxButtons.getChildren().addAll(obliterateAll()/*, refreshCButton()*/);
		return vbxButtons;
	}
	
	public BorderPane buildGraph() {
		bpGraph.setTop(buildTop());
		bgVolume.getData().add(data);
		bpGraph.setCenter(bgVolume);
		
		return bpGraph;
	}
	
	public Button displayAllMartians() {
		DisplayAllMartiansEventHandler daMEventHandler = new DisplayAllMartiansEventHandler();
		displayAllMartians.setText("Display Martians");
		displayAllMartians.setOnAction(daMEventHandler);
		displayAllMartians.setId("padding");
		
		return displayAllMartians;
	}
	
	
	//builds the comboBox options
	public ComboBox<String> buildComboBox(){		
		cmbSelect.getItems().addAll("Add Martians", "Group Teleport", "Retrieve specific Martian", 
				"Remove specific Martian", "Change Martian Volume");
		cmbSelect.setValue("Add Martians");
		
		SelectEventHandler cmbSelectEventHandler = new SelectEventHandler();
		cmbSelect.setOnAction(cmbSelectEventHandler);
		
		return cmbSelect;
	}
	
	//constructs the radioButton to allow both martians to be added
	public RadioButton addBoth() {
		
		addB = new RadioButton("Both Martians");
		addB.setSelected(true);
		addB.setToggleGroup(martians);
		addB.setOnAction(radioControlEventHandler);
		
		return addB;
	}
	
	public RadioButton addRed() {
		addR = new RadioButton("Red Martian");
		addR.setToggleGroup(martians);
		addR.setOnAction(radioControlEventHandler);
		
		return addR;
	}
	
	public RadioButton addGreen() {
		addG = new RadioButton("Green Martian");
		addG.setToggleGroup(martians);
		addG.setOnAction(radioControlEventHandler);
		
		return addG;
	}
	
	//used to bring the add Martian drop down box working
	public void addMartianTemp() {
		lbRM.setVisible(true);
		lbRM.setText("Red Martians");
		tfRed.setVisible(true);
		tfGreen.setVisible(true);
		lbGM.setVisible(true);
		addR.setVisible(true);
		addG.setVisible(true);
		addB.setVisible(true);
		addR.setSelected(false);
		addB.setSelected(true);
		addMartianEventHandler addButtons = new addMartianEventHandler();
		addButton.setText("Add Martians");
		addButton.setOnAction(addButtons);
		addB.setSelected(true);
		lbMinN.setVisible(true);
		lbMaxN.setVisible(true);
		sVolume.setVisible(false);
		lbDisplay.setVisible(true);
		cmbMartians.setVisible(true);
		if(addB.isSelected() == false) {
			esp.setVisible(true);
			veg.setVisible(true);
		}
		if(addB.isSelected() == false) {
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
		volume.setVisible(true);
		lbtVolume.setVisible(true);
	}
	
	//allows us to hide/show things that should be or shouldn't be there
	public void showFields(char c) {
		
		if(c == 'R') {
			lbRM.setVisible(true);
			tfRed.setVisible(true);
			lbMinN.setVisible(true);
			lbMaxN.setVisible(true);
			esp.setVisible(true);
			veg.setVisible(true);
			volume.setVisible(true);
			lbtVolume.setVisible(true);
			if(lbGM.isVisible() && tfGreen.isVisible()) {
				lbGM.setVisible(false);
				tfGreen.setVisible(false);
				sVolume.setVisible(false);
				
			}
		}
		else if(c == 'G') {
			tfGreen.setVisible(true);
			lbGM.setVisible(true);
			lbMinN.setVisible(true);
			lbMaxN.setVisible(true);
			esp.setVisible(true);
			veg.setVisible(true);
			volume.setVisible(true);
			lbtVolume.setVisible(true);
			if(lbRM.isVisible() && tfRed.isVisible()) {
				lbRM.setVisible(false);
				tfRed.setVisible(false);
				sVolume.setVisible(false);
			}
		}
		else if(c == 'B') {
			lbRM.setVisible(true);
			tfRed.setVisible(true);
			tfGreen.setVisible(true);
			lbGM.setVisible(true);
			sVolume.setVisible(false);
			esp.setVisible(false);
			veg.setVisible(false);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
	}
	
	//constructs the add martain button
	public Button addButton() {
		addMartianEventHandler addButtons = new addMartianEventHandler();
		addButton.setText("Add Martians");
		addButton.setOnAction(addButtons);
		addButton.setId("padding");
		
		return addButton;
	}
	
	//constructs the read martian button
	public Button readButton() {
		ReadEventHandler rEventHandler = new ReadEventHandler();
		readButton.setText("Read Martian file");
		readButton.setOnAction(rEventHandler);
		readButton.setId("padding");
		
		return readButton;
	}
	
	//constructs the write martian button
	public Button writeFromListButton() {
		WriteFromListEventHandler WFFEventHandler = new WriteFromListEventHandler();
		writeFromListButton.setText("Write Martians from list");
		writeFromListButton.setOnAction(WFFEventHandler);
		writeFromListButton.setId("padding");
		
		return writeFromListButton;
	}
	
/*	public Button refreshCButton() {
		refreshComboEventHandler rcEventHandler = new refreshComboEventHandler();
		refreshC.setText("Refresh Martian ComboBox");
		refreshC.setOnAction(rcEventHandler);
		
		return refreshC;
	}*/
	
	public void addBothMartian() {
			if(addB.isSelected()) {
				rm = new RedMartian(Integer.parseInt(tfRed.getText()));
				gm = new GreenMartian(Integer.parseInt(tfGreen.getText()));
				if(mm.addMartian(rm)) {
					System.out.println("Martians entered");
					txaD.appendText("\nRedMartian entered.");
					MM.add(rm);
				}
				else {
					txaD.appendText("\nRedMartian failed to enter, due to another martian with an identical id");
				}
				if(mm.addMartian(gm)) {
					System.out.println("GreenMartian entered");
					txaD.appendText("\nGreenMartian entered.");
				}
				else {
					txaD.appendText("\nGreenMartian failed to enter, due to another martian with an identical id");
				}
			}
			personalTester();
	}
	
	public void addGreenMartian() {
		if(addG.isSelected()) {
			if(esp.isSelected() && veg.isSelected()) {
				gm = new GreenMartian(Integer.parseInt(tfGreen.getText()), 0, true, true);
			}
			else if(esp.isSelected() && veg.isSelected() == false) {
				gm = new GreenMartian(Integer.parseInt(tfGreen.getText()), 0, true, false);
			}
			else if(esp.isSelected() == false && veg.isSelected()) {
				gm = new GreenMartian(Integer.parseInt(tfGreen.getText()), 0, false, true);
			}
			else if (esp.isSelected() == false && veg.isSelected() == false) {
				gm = new GreenMartian(Integer.parseInt(tfGreen.getText()), 0, false, false);
			}
			if(mm.addMartian(gm)) {
				System.out.println("Martian entered");
				MM.add(gm);
				txaD.appendText("\nGreen Martian Entered!");
				personalTester();
			}
			else {
				txaD.appendText("\nGreenMartian failed to add, because there was another Martian with the same id."
						+ "Please try another id");
			}
		}
	}
	
	public void addRedMartian() {
		if(addR.isSelected()) {
			if(esp.isSelected() && veg.isSelected()) {
				rm = new RedMartian(Integer.parseInt(tfRed.getText()), 0, true, true);
			}
			else if(esp.isSelected() && veg.isSelected() == false) {
				rm = new RedMartian(Integer.parseInt(tfRed.getText()), 0, true, false);
			}
			else if(esp.isSelected() == false && veg.isSelected()) {
				rm = new RedMartian(Integer.parseInt(tfRed.getText()), 0, false, true);
			}
			else if (esp.isSelected() == false && veg.isSelected() == false) {
				rm = new RedMartian(Integer.parseInt(tfRed.getText()), 0, false, false);
			}
			if(volume.getText().isEmpty() == false) {
				rm.setVolume(Integer.parseInt(volume.getText()));
			}
			if(mm.addMartian(rm)) {
				System.out.println("Number entered");
				MM.add(rm);
				txaD.appendText("\nRed Martian Entered!");
				personalTester();
			}
			else {
				txaD.appendText("\nRedMartian failed to add, because there was another Martian with the same id."
						+ "Please try another id");
			}
		}
	}
	
	//changes the needed controls to allow us to make another field
	public void teleportTextField() {
		lbRM.setText("Group Teleport");
		hideFields("Group Teleport");
		
		TeleportEventHandler tpEventHandler = new TeleportEventHandler();
		addButton.setText("Teleport");
		addButton.setOnAction(tpEventHandler);
		
	}
	
	public void teleport() {
		txaD.appendText("\n" + mm.groupTeleport(tfRed.getText()));
		System.out.println(mm.groupTeleport(tfRed.getText()));
	}
	
	public void retrieveAMartian() {
		lbRM.setText("Retrieve A Martian");
		hideFields("Retrieve A Martian");
		
		RetrieveAMartianEventHandler rAMEventHandler = new RetrieveAMartianEventHandler();
		addButton.setText("Retrieve A Martian");
		addButton.setOnAction(rAMEventHandler);
	}
	
	public void removeAMartian() {
		lbRM.setText("Remove A Martian");
		hideFields("Remove A Martian");
		
		RemoveAMartianEventHandler rAMEventHandler = new RemoveAMartianEventHandler();
		addButton.setText("Remove A Martian");
		addButton.setOnAction(rAMEventHandler);
		
	}
	
	public void changeMartianVolume() {
		buildSlider();
		hideFields("Change Martian Volume");
		lbRM.setText("Enter a Martian id");
		addButton.setText("Change Volume");
		
		VolumeEventHandler vEventHandler = new VolumeEventHandler();
		addButton.setOnAction(vEventHandler);
		
	}
	
	public void displaySortedList() {
		txaD.appendText("\n" + mm.sortedMartians());
	}
	
	public void buildSlider() {
		sVolume.setMin(0);
		sVolume.setMax(100);
		sVolume.setShowTickLabels(true);
		sVolume.setShowTickMarks(true);
		sVolume.setMajorTickUnit(1);
		sVolume.setMinorTickCount(0);
		sVolume.setBlockIncrement(10);
		sVolume.setLayoutX(100);
		sVolume.setSnapToTicks(true);
	}
	
	/*public ComboBox<String> martianComboBox() {
		cmbMartians = new ComboBox<String>();	
		
		cmbMartians.getItems().addAll(MM);
		MartianDisplayEventHandler mEventHandler = new MartianDisplayEventHandler();
		cmbMartians.setOnAction(mEventHandler);
		
		return cmbMartians;
	}*/
	
	public void readMartianFile(File file) {
		int id; 
		int vol;
		boolean esp;
		boolean veg;
		try {
			Scanner inFile = new Scanner(file);
			while(inFile.hasNext()) {
				String line = inFile.nextLine();
				System.out.println(line);
				String[] token = line.split("\\s+");
				System.out.println(token.length);
				String letter = token[0];
				id = Integer.parseInt(token[1]);
				switch(letter) {
					case("R"):
						if(token.length == 2) {
							RedMartian rm = new RedMartian(id, 0, false, false);
						}
						else if(token.length == 3) {
							RedMartian rm = new RedMartian(id, Integer.parseInt(token[2]), false, false);
						}
						else if(token.length == 4) {
							RedMartian rm = new RedMartian(id, Integer.parseInt(token[2]), letterDecider(token, 3), false);
						}
						else if(token.length == 5) {
							RedMartian rm = new RedMartian(id, Integer.parseInt(token[2]), letterDecider(token, 3), letterDecider(token, 4));
						}
						break;
					default:
						txaD.appendText("Nothing worked. Check file");
						break;
				}
			}
			inFile.close();
		}
		catch(Exception e) {
			txaD.appendText("\nFile not Found");
		}
	}
	
	public boolean letterDecider(String[] token, int p) {
		if(token[p].equals("t")) {
			return true;
		}
		else {
			return false;
		}
	}
	public void writeFromList(File file) {
		char t;
		char f;
		try {
			PrintWriter pw = new PrintWriter(file);
			for(int i = 0; i < mm.getNumMartians(); i++) {
				if(mm.getMartianAt(i) instanceof RedMartian) {
					if(mm.getMartianAt(i).hasESP() && mm.getMartianAt(i).isVegetarian()) {
						pw.printf("\nR %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 't', 't');
					}
					else if(mm.getMartianAt(i).hasESP() == false && mm.getMartianAt(i).isVegetarian()) {
						pw.printf("\nR %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 'f', 't');
					}
					else if(mm.getMartianAt(i).hasESP() && mm.getMartianAt(i).isVegetarian() == false) {
						pw.printf("\nR %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 't', 'f');
					}
					else if(mm.getMartianAt(i).hasESP() == false && mm.getMartianAt(i).isVegetarian() == false) {
						pw.printf("\nR %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 'f', 'f');
					}
				}
				else if(mm.getMartianAt(i) instanceof GreenMartian) {
					if(mm.getMartianAt(i).hasESP() && mm.getMartianAt(i).isVegetarian()) {
						pw.printf("\nG %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 't', 't');
					}
					else if(mm.getMartianAt(i).hasESP() == false && mm.getMartianAt(i).isVegetarian()) {
						pw.printf("\nG %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 'f', 't');
					}
					else if(mm.getMartianAt(i).hasESP() && mm.getMartianAt(i).isVegetarian() == false) {
						pw.printf("\nG %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 't', 'f');
					}
					else if(mm.getMartianAt(i).hasESP() == false && mm.getMartianAt(i).isVegetarian() == false) {
						pw.printf("\nG %d %d %b %b\n", mm.getMartianAt(i).getId(), mm.getMartianAt(i).getVolume(), 'f', 'f');
					}
				}
			}
			pw.close();
		}
		catch(Exception e) {
			txaD.appendText("Issue with the file" + e);
		}
	}
	
	//hides the fields not needed based on the supplied string that is sent from a method call
	public void hideFields(String word) {
		if(word.equals("Group Teleport")) {
			tfRed.setVisible(true);
			tfGreen.setVisible(false);
			lbGM.setVisible(false);
			lbMinN.setVisible(false);
			lbMaxN.setVisible(false);
			lbRM.setVisible(true);
			addR.setVisible(false);
			addG.setVisible(false);
			addB.setVisible(false);
			lbSelect.setVisible(false);
			sVolume.setVisible(false);
			lbVolume.setVisible(false);
			lbDisplay.setVisible(false);
			cmbMartians.setVisible(false);
			esp.setVisible(false);
			veg.setVisible(false);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
		else if(word.equals("Retrieve A Martian")) {
			tfRed.setVisible(true);
			tfGreen.setVisible(false);
			lbGM.setVisible(false);
			lbMinN.setVisible(false);
			lbMaxN.setVisible(false);
			lbRM.setVisible(true);
			addR.setVisible(false);
			addG.setVisible(false);
			addB.setVisible(false);
			lbSelect.setVisible(false);
			sVolume.setVisible(false);
			lbVolume.setVisible(false);
			lbDisplay.setVisible(false);
			cmbMartians.setVisible(false);
			esp.setVisible(false);
			veg.setVisible(false);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
		else if(word.equals("Remove A Martian")) {
			tfRed.setVisible(true);
			tfGreen.setVisible(false);
			lbGM.setVisible(false);
			lbMinN.setVisible(false);
			lbMaxN.setVisible(false);
			lbRM.setVisible(true);
			addR.setVisible(false);
			addG.setVisible(false);
			addB.setVisible(false);
			lbSelect.setVisible(false);
			sVolume.setVisible(false);
			lbVolume.setVisible(false);
			lbDisplay.setVisible(false);
			cmbMartians.setVisible(false);
			esp.setVisible(false);
			veg.setVisible(false);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
		else if(word.equals("Change Martian Volume")) {
			tfRed.setVisible(true);
			tfGreen.setVisible(false);
			lbGM.setVisible(false);
			lbMinN.setVisible(false);
			lbMaxN.setVisible(false);
			lbRM.setVisible(true);
			addR.setVisible(false);
			addG.setVisible(false);
			addB.setVisible(false);
			lbSelect.setVisible(true);
			sVolume.setVisible(true);
			lbVolume.setVisible(true);
			esp.setVisible(false);
			veg.setVisible(false);
			volume.setVisible(false);
			lbtVolume.setVisible(false);
		}
	}
	
	public HBox buildTop() {
		graphEventHandler gEventHandler = new graphEventHandler();
		
		bar.setText("Bar Graph");
		bar.setToggleGroup(graph);
		bar.setSelected(true);
		bar.setOnAction(gEventHandler);
		
		pie.setText("Pie Chart");
		pie.setToggleGroup(graph);
		pie.setOnAction(gEventHandler);
		
		hbxRadioButton.getChildren().addAll(bar, pie);
		return hbxRadioButton;
	}

	//todo get graph working for inside
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void buildBarGraph() {
		xAxis.setLabel("Martian id's");
		yAxis.setLabel("Martian volumes");
		
		data.setName("Volumes");
		if(bar.isSelected() == true) {
			for(int i = 0; i < MM.size(); i++) {
				data.getData().add(new XYChart.Data(String.valueOf(MM.get(i).getId()), MM.get(i).getVolume()));
			}
		}
	}
	
	public void buildPieChart() {
		
	}
	
	public Button obliterateAll() {
		obliterateAllEventHandler oAEventHandler = new obliterateAllEventHandler();
		Obliterate.setText("Destroy All Martians");
		Obliterate.setOnAction(oAEventHandler);
		Obliterate.setId("obliterate");
		
		return Obliterate;
	}
	
	private class SelectEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			String dropDown = (String) cmbSelect.getValue();
			switch(dropDown) {
			
			case("Add Martians"):
				System.out.println("Add Martians event fired!");
				addMartianTemp();
				break;
			case("Group Teleport"):
				System.out.println("Group Teleport event fired!");
				otherFrames("Group Teleport");
				break;
			case("Retrieve specific Martian"):
				System.out.println("Retrieve specific Martian event fired!");
				otherFrames("Retrive specific Martian");
				break;
			case("Remove specific Martian"):
				System.out.println("Remove specific Martian event fired!");
				otherFrames("Remove specific Martian");
				break;
			case("Change Martian Volume"):
				System.out.println("Change Martian Volume event fired!");
				otherFrames("Change Martian Volume");
				break;
			default:
				System.out.println("Nothing worked!");
				break;
			}
		}
	}
	
	private class MartianEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			RadioButton radMartian = (RadioButton)martians.getSelectedToggle();
			
			String word = radMartian.getText();
			
			switch(word) {
				case("Red Martian"):
					System.out.println("Red Martian event fired!");
					showFields('R');
					break;
				case("Green Martian"):
					System.out.println("Green Martian event fired!");
					showFields('G');
					break;
				case("Both Martians"):
					System.out.println("Both Martians event fired!");
					showFields('B');
					break;
				default:
					System.out.println("Nothing worked!");
					break;
			}
		}
	}
	
	private class addMartianEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			if(addB.isSelected()) {
				if(tfRed.getText().isEmpty() == false && tfGreen.getText().isEmpty() == false) {
					txaD.appendText("\nnumber entered for Red martains " + tfRed.getText());
					System.out.println("number entered for red martains" + tfRed.getText());
					txaD.appendText("\nnumber entered for green martains " + tfGreen.getText());
					System.out.println("number entered for green martains " + tfGreen.getText());
					System.out.println(tfRed.getText() + " Both worked! " + tfGreen.getText());
					addBothMartian();
				}
				else if(tfRed.getText().isEmpty() && tfGreen.getText().isEmpty() == false) {
					txaD.appendText("\nEither swap to a single martian or enter missing id");
					System.out.println("Either swap to a single martian or enter missing number");
				}
				else if(tfGreen.getText().isEmpty() && tfRed.getText().isEmpty() == false) {
					txaD.appendText("\nEither swap to a single martian or enter missing id");
					System.out.println("Either swap to a single martian or enter missing number");
				}
				else {
					System.out.println("Everything failed!");
					txaD.appendText("\nEverything failed!");
				}
			}
			else if(addG.isSelected()) {
				if(tfGreen.getText().isEmpty()) {
					System.out.println("Green failure!");
					txaD.appendText("\nPlease enter a Green Martian Id!");
				}
				else {
					System.out.println("Green Martian id acceptable");
					txaD.appendText("\nEntering Green Martian id!");
					addGreenMartian();
				}
			}
			else if(addR.isSelected()) {
				if(tfRed.getText().isEmpty()) {
					System.out.println("Red failure!");
					txaD.appendText("\nPlease enter a Red Martian Id!");
				}
				else {
					System.out.println("Red Martian id acceptable");
					txaD.appendText("\nEntering Red Martian id! ");
					addRedMartian();
				}
			}
		}
	}

	private class TeleportEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			if(mm.getNumTeleporters() > 0) {
				System.out.println("Teleporting");
				txaD.appendText("\nTeleporting");
				teleport();
			}
			else {
				txaD.appendText("\nPlease enter a Green Martian and try again");
			}
		}
	}
	
	private class RetrieveAMartianEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof RedMartian) {
				rm = (RedMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
				txaD.appendText("\n" + tfRed.getText() + " Informational facts\n");
				txaD.appendText(rm.toString() + " " +rm.speak());
			}
			else if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof GreenMartian) {
				gm = (GreenMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
				txaD.appendText("\n" + tfRed.getText() + " Informational facts\n");
				txaD.appendText(gm.toString() + " " + gm.speak());
			}
			else {
				txaD.appendText("\nMartian not found!");
				System.out.println("Martain not found!");
			}
		}
	}
	
	private class RemoveAMartianEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			RedMartian temp1 ;
			GreenMartian temp2;
			if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof Martian){
				txaD.appendText("\nRemoving Martian: " + tfRed.getText());
				if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof RedMartian) {
					temp1 = (RedMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
					if(MM.contains(temp1)) {
						MM.remove(temp1);
					}
				}
				else {
					temp2 = (GreenMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
					if(MM.contains(temp2)) {
						MM.remove(temp2);
					}
 				}
				txaD.appendText("\nRemoving: " + mm.removeMartian(Integer.parseInt(tfRed.getText())));
				
			}
			else {
				txaD.appendText("\nMartian not found!");
				System.out.println("Martain not found!");
			}
		}
	}
	
	private class MartianDisplayEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			String temp = (String) cmbMartians.getValue();
			txaD.appendText("\n" + temp);
			System.out.println(temp);
		}
	}
	
	private class VolumeEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof RedMartian) {
				rm = (RedMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
				rm.setVolume((int)sVolume.getValue());
				txaD.appendText("RedMartians " + Integer.parseInt(tfRed.getText()) + " Volume changed to " + rm.getVolume());
				System.out.println(rm.toString());
			}
			else if(mm.getMartianWithId(Integer.parseInt(tfRed.getText())) instanceof GreenMartian) {
				gm = (GreenMartian) mm.getMartianWithId(Integer.parseInt(tfRed.getText()));
				gm.setVolume((int)sVolume.getValue());
				txaD.appendText("GreenMartians " + Integer.parseInt(tfRed.getText()) + " Volume changed to " + gm.getVolume());
			}
		}
	}
	
	private class ReadEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			FileChooser fileChooser = new FileChooser();
			File selectFile = fileChooser.showOpenDialog(null);
			
			if(selectFile != null) {
				txaD.appendText("File choosen  " + selectFile.getName());
				System.out.println("File choosen");
				readMartianFile(selectFile);
				
			}
			else {
				txaD.appendText("That file is not reachable");
			}
		}
	}
	
	private class WriteFromListEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			FileChooser fileChooser = new FileChooser();
			File selectFile = fileChooser.showOpenDialog(null);
			
			if(selectFile != null) {
				writeFromList(selectFile);
				System.out.println("File choosen");
			}
			else {
				txaD.appendText("File failed to find");
			}
		}
	}
	
	private class graphEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			if(bar.isSelected()) {
				buildBarGraph();
			}
			else if(pie.isSelected()) {
				buildPieChart();
			}
		}
	}
	
	private class DisplayAllMartiansEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			txaD.appendText("\n" + mm.sortedMartians());
		}
	}
	
	private class obliterateAllEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			mm.obliterateMartians();
			mm.obliterateTeleporters();
			MM.clear();
			txaD.appendText("\nAll Martians earsed");
			personalTester();
		}
	}
	
/*	private class refreshComboEventHandler implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {
			martianComboBox();
		}
	}*/
	public void personalTester() {
		for(int i = 0; i < MM.size(); i++) {
			System.out.println(MM.get(i));
		}
	}
	public static void main(String[] args) {
		launch(args);
		/*MartianManager mm = new MartianManager();
		mm.addMartian(new GreenMartian(33,99,true,false));
		System.out.println(mm.groupSpeak());
		for(int i=0; i<mm.getNumMartians(); i++) {
			System.out.println(mm.getMartianAt(i));
		}*/
	}
}