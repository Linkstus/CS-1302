package exception_examples1;

public class Example1 {

	public static void main(String[] args) {
		System.out.println("Answers:");
		System.out.println("a. StringIndexOutOfBoundsException ");
		System.out.println("b. calling a string index position that does not exist ");
		System.out.println("c. the lines of code that is causing the issues ");
		System.out.println("d. it does not because once it hits the OutOfBoundsException it ends the code"
				+ " ");

		
		char c = getCharAt("help", 8);
		System.out.println( c );
	}
	
	public static char getCharAt(String msg, int pos) {
		return msg.charAt(pos);
	}
}

