package exception_examples1;

public class Example2 {
	
	public static void main(String[] args) {
		System.out.println("Answers:");
		System.out.println("i. because c is defined within the try block so unless that code is excuted and stays executed it will never be defined");
		System.out.println("ii. true ");
		System.out.println("iii. outside ");

		
		char c;
		try {
			c = getCharAt("help", 8);
			System.out.println("Got the answer!");
		}
		catch(RuntimeException e) {
			System.out.println("Exception:\n  " + e);
			c = '*';
		}
		System.out.println( "Character is: " + c );
	}
	
	public static char getCharAt(String msg, int pos) {
		return msg.charAt(pos);
	}
}

