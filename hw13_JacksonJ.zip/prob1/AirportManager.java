package prob1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class AirportManager {
	protected HashMap<String, Airport> map = new HashMap<>();
	
	public AirportManager(Map<String, Airport> airport) {
		this.map = (HashMap<String, Airport>)airport;
	}
	
	public Airport getAirport(String code) {
		return map.get(code);
	}
	
	public double getDistanceBetween(Airport airport1, Airport airport2) {
		DistanceCalculator dc = new DistanceCalculator();
		double dist = dc.getDistance(airport1.getLatitude(), airport1.getLongitude(), airport2.getLatitude(), airport2.getLongitude());
		return dist;
	}
	
	public double getDistanceBetween(String code1, String code2) {
		DistanceCalculator dc = new DistanceCalculator();
		double dist = dc.getDistance(map.get(code1).getLatitude(), map.get(code1).getLongitude(), map.get(code2).getLatitude(), map.get(code2).getLongitude());
		return dist;
	}
	
	public Airport getAirportClosestTo(String code) {
		double min = Double.MAX_VALUE;
		Set<String> key = map.keySet();
		Iterator<String> iter = key.iterator();
		DistanceCalculator dc = new DistanceCalculator();
		Airport returnAirport = new Airport(" ", 0.0, 0.0, " ", " ");
		
		while(iter.hasNext()) {
			String k = iter.next();
			if(!k.equals(code)) {
				double temp = dc.getDistance(map.get(code).getLatitude(), map.get(code).getLongitude(), map.get(k).getLatitude(), map.get(k).getLongitude());
				if(temp < min) {
					min = temp;
					returnAirport = map.get(k);
				}
			}
		}
		return returnAirport;
	}
	
	public List<Airport> getAirportsWithin(String code, double withinDist){
		ArrayList<Airport> list = new ArrayList<>();
		DistanceCalculator dc = new DistanceCalculator();
		Set<String> key = map.keySet();
		Iterator<String> iter = key.iterator();
		
		while(iter.hasNext()) {
			String k = iter.next();
			if(!k.equals(code)) {
				double temp = dc.getDistance(map.get(code).getLatitude(), map.get(code).getLongitude(), map.get(k).getLatitude(), map.get(k).getLongitude());
				if(temp <= withinDist) {
					list.add(map.get(k));
				}
			}
		}
		return list;
	}
	
	public List<Airport> getAirportsWithin(String code1, String code2, double withinDist){
		ArrayList<Airport> temp1 = new ArrayList<>();
		ArrayList<Airport> temp2 = new ArrayList<>();
		
		temp1 = (ArrayList<Airport>) getAirportsWithin(code1, withinDist);
		temp2 = (ArrayList<Airport>) getAirportsWithin(code2, withinDist);
		
		ArrayList<Airport> returnList = new ArrayList<>(temp1);
		
		returnList.retainAll(temp2);
		
		return returnList;
	}
	
	public List<Airport> getAirportsSortedBy(String sortType){
		Set<String> temp = map.keySet();
		ArrayList<Airport> list1 = new ArrayList<>();
		Iterator<String> iter = temp.iterator();
		
		while(iter.hasNext()) {
			String key = iter.next();
			list1.add(map.get(key));
		}
		
		if(sortType.equals("City")) {
			Collections.sort(list1, new CityComparator());
			return list1;
		}
		else {
			Collections.sort(list1, new StateComparator());
			return list1;
		}
	}
	
	public List<Airport> getAirportsClosestTo(String code, int num){
		ArrayList<Airport> list = new ArrayList<>();
		DistanceCalculator dc = new DistanceCalculator();
		LinkedHashMap<Double, Airport> tempMap = new LinkedHashMap<>();
		Set<String> keys = map.keySet();
		Iterator<String> iter = keys.iterator();
		
		while(iter.hasNext()) {
			String key = iter.next();
			if(!key.equals(code)) {
				double distance = dc.getDistance(map.get(code).getLatitude(), map.get(code).getLongitude(), map.get(key).getLatitude(), map.get(key).getLongitude());
				tempMap.put(distance, map.get(key));
			}
		}
		ArrayList<Double> distances = new ArrayList<>(tempMap.keySet());
		Collections.sort(distances);
		
		for(int i = 0; i < num; i++) {
			double temp = distances.get(i);
			list.add(tempMap.get(temp));
		}
		
		return list;
	}
	
	public List<Airport> getAirportsByCity(String city){
		ArrayList<Airport> returnList = new ArrayList<>();
		ArrayList<Airport> temp = new ArrayList<>(map.values());
		
		for(int i = 0; i < temp.size(); i++) {
			if(temp.get(i).getCity().equals(city)){
				returnList.add(temp.get(i));
			}
		}
		
		return returnList;
	}
	
	public List<Airport> getAirportsByCityState(String city, String state){
		ArrayList<Airport> returnList = new ArrayList<>();
		ArrayList<Airport> temp = new ArrayList<>(map.values());
		
		for(int i = 0; i < temp.size(); i++) {
			if(temp.get(i).getCity().equals(city) && temp.get(i).getState().equals(state)){
				returnList.add(temp.get(i));
			}
		}
		
		return returnList;
	}
	
	public List<Airport> getNWSNamedAirports(){
		ArrayList<Airport> returnList = new ArrayList<>();
		ArrayList<Airport> temp = new ArrayList<>(map.values());

		for(int i = 0; i < temp.size(); i++) {
			char t = temp.get(i).getCode().charAt(2);
			if(t == 'X') {
				returnList.add(temp.get(i));
			}
		}
		return returnList;
	}
	
	public List<Airport> getAirportsWithin(double withinDist, double lat, double lon){
		Airport a1 = new Airport(" ", lat, lon, " ", " ");
		map.put(" ", a1);
		
		ArrayList<Airport> temp = (ArrayList<Airport>) getAirportsWithin(a1.getCode(), withinDist);
		
		return temp;
	}
}
