package prob1;

import java.util.ArrayList;

public class GenericMartianManager<T extends Martian> {

	protected ArrayList<T> martians = new ArrayList<>();
	protected int index;
	
	public boolean addMartian(T m) {
		 if(!martians.contains(m)) {
			 return martians.add(m);
		 }
		 else {
			 return false;
		 }
	}
	
	public int getNumMartians() {
		return martians.size();
	}
	
	public T getMartian(T m) {
		index = martians.indexOf(m);
		
		if(index != -1) {
			return martians.get(index);
		}
		else {
			return null;
		}
	}
	
	public void mergeMartians(ArrayList<? extends T> marts) {
		martians.addAll(marts);
	}
	
	public boolean removeMartian(T m) {
		index = martians.indexOf(m);
		
		if(index != -1) {
			return martians.remove(m);
		}
		else {
			return false;
		}
	}
}
