package prob1;
import java.util.ArrayList;

public abstract class Computer implements HTTP{
	protected ArrayList<DataBlock> dataBlock = new ArrayList<>();
	protected double processorSpeed;
	protected double ram;
	
	Computer(double proccessorSpeed, double ram){
		this.processorSpeed = processorSpeed;
		this.ram = ram;
	}
	
	public double getProcessorSpeed() {
		return processorSpeed;
	}
	
	public double getRam() {
		return ram;
	}
	
	public DataBlock getBlock(int i) {
		return dataBlock.get(i);
	}
	
	public Tone makeSound(String s) {
		Tone t = new Tone(s);
		return t;
	}
	
	public boolean cache(DataBlock db) {
		if(dataBlock.contains(db)) {
			return false;
		}
		else {
			dataBlock.add(db);
			return true;
		}
	}
	
	public abstract void runProgram(ArrayList<String> instructions);
}
