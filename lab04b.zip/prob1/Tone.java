package prob1;

public class Tone {
	protected String sound;
	
	Tone(String sound){
		this.sound = sound;
	}
	
	public String toString() {
		 String s = String.format("Tone sound: %s", sound);
		return s;
	}
	
}
