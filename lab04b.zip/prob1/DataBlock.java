package prob1;

import java.util.ArrayList;

public class DataBlock {
	protected ArrayList<String> data = new ArrayList<>();
}
