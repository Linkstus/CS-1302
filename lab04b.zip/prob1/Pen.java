package prob1;

public class Pen {

}
