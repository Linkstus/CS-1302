package prob1;

public interface HTTP {

	public boolean cache(DataBlock db);
}
