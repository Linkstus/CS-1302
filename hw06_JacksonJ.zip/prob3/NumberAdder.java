package prob3;

import java.io.File;
import java.util.Scanner;

public class NumberAdder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addingMachine();
	}
	
	public static void addingMachine() {
		File file = new File("src\\prob3\\values.txt");
		double sum = 0;
		int numToSkip = 0;
			
		try {
			Scanner readFile = new Scanner(file);
			
			while(readFile.hasNext()) {
				try {
					sum += readFile.nextInt();
					System.out.println(sum);
				}
				catch(Exception e) {
					numToSkip = Integer.parseInt(readFile.next().substring(1));
					for(int i  = 0; i < numToSkip; i++) {
						readFile.next();
					}
				}
				
			}
			readFile.close();
		}
		catch(Exception e) {
			System.out.println("File not found");
		}
		System.out.println("Sum: " + sum);
	}

}
