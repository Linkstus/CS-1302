package prob1;

public class Dog {
	
	private int val;
	
	public Dog(int val) {
		this.val = val;
	}
	
	public String toString() {
		return "d(" + val + ")";
	}
}

