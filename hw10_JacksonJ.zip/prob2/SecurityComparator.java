package prob2;

import java.util.Comparator;

public class SecurityComparator implements Comparator<Job> {

	public int compare(Job j1, Job j2) {
		int comparision = j2.getSecurityLevel() - j1.getSecurityLevel();
		
		if(comparision == 0) {
			return j2.getPriority() - j1.getPriority();
		}
		else {
			return comparision;
		}
	}
}
