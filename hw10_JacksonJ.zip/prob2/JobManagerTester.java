package prob2;

import java.util.Iterator;

public class JobManagerTester {
	public static void main(String [] args) {
		testAdding();
		testPoll();
		testChangingPriority();
		testFlush();
	}
	
	public static void testAdding() {
		System.out.println("Test one: Adding new Jobs");
		Job cooking = new Job(7, 3);
		Job fishing = new Job(7, 5);
		Job stableHand = new Job(2, 1);
		Job builder = new Job(5, 4);
		Job butcher = new Job(7, 5);
		Job steelWorker = new Job(3, 3);
		Job miner = new Job(2, 2);
		Job dishwasher = new Job(4, 0);
		Job dog = new Job(-1, -5);
		
		JobManager jb = new JobManager(true);
		
		jb.offer(stableHand);
		jb.offer(cooking);
		jb.offer(fishing);
		jb.offer(dishwasher);
		jb.offer(miner);
		jb.offer(steelWorker);
		jb.offer(butcher);
		jb.offer(builder);
		jb.offer(cooking);
		jb.offer(dog);
		
		System.out.println(jb.peak());
		System.out.println("-------------------------");
	}
	
	public static void testPoll() {
		System.out.println("Test two: peak/poll/isEmpty");
		Job cooking = new Job(7, 3);
		Job fishing = new Job(7, 5);
		Job stableHand = new Job(2, 1);
		Job builder = new Job(5, 4);
		Job butcher = new Job(7, 5);
		Job steelWorker = new Job(3, 3);
		Job miner = new Job(2, 2);
		Job dishwasher = new Job(4, 0);
		Job dog = new Job(-1, -5);
		
		JobManager jb = new JobManager(true);
		
		jb.offer(stableHand);
		jb.offer(cooking);
		jb.offer(fishing);
		jb.offer(dishwasher);
		jb.offer(miner);
		jb.offer(steelWorker);
		jb.offer(butcher);
		jb.offer(builder);
		jb.offer(dog);
		
		System.out.println("isEmpty 1");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 1");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 1");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Peak 2");
		System.out.println(jb.peak());
		System.out.println("           ");
		System.out.println("Poll 2");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Poll 3");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Poll 4");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("isEmpty 2");
		System.out.println(jb.isEmpty());
		System.out.println("           ");
		System.out.println("Peak 3");
		System.out.println(jb.peak());
		System.out.println("           ");
		System.out.println("Poll 5");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Poll 6");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Poll 7");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Peak 4");
		System.out.println(jb.peak());
		System.out.println("           ");
		System.out.println("Poll 8");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Peak 5");
		System.out.println(jb.peak());
		System.out.println("           ");
		System.out.println("Poll 9");
		System.out.println(jb.poll());
		System.out.println("           ");
		System.out.println("Peak 6");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("isEmpty 3");
		System.out.println(jb.isEmpty());
		System.out.println("-----------------------");
	}
	
	public static void testChangingPriority() {
		System.out.println("Test three: peak/poll/isEmpty");
		Job cooking = new Job(7, 3);
		Job fishing = new Job(7, 5);
		Job stableHand = new Job(2, 1);
		Job builder = new Job(5, 4);
		Job butcher = new Job(7, 5);
		Job steelWorker = new Job(3, 3);
		Job miner = new Job(2, 2);
		Job dishwasher = new Job(4, 0);
		Job dog = new Job(-1, -5);
		
		JobManager jb = new JobManager(true);
		
		jb.offer(stableHand);
		jb.offer(cooking);
		jb.offer(fishing);
		jb.offer(dishwasher);
		jb.offer(miner);
		jb.offer(steelWorker);
		jb.offer(butcher);
		jb.offer(builder);
		jb.offer(dog);
		
		System.out.println("isEmpty 1");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 1");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 1");
		System.out.println(jb.poll());
		System.out.println("         ");
		
		jb.setPriority(false);
		System.out.println("Priority: " + jb.getPriority());
		
		System.out.println("isEmpty 2");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 2");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 2");
		System.out.println(jb.poll());
		System.out.println("         ");
		
		jb.setPriority(true);
		System.out.println("Priority: " + jb.getPriority());
		
		System.out.println("isEmpty 3");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 3");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 3");
		System.out.println(jb.poll());
		System.out.println("         ");
		
		
	}
	
	public static void testFlush() {
		System.out.println("Test three: peak/poll/isEmpty");
		Job cooking = new Job(7, 3);
		Job fishing = new Job(7, 5);
		Job stableHand = new Job(2, 1);
		Job builder = new Job(5, 4);
		Job butcher = new Job(7, 5);
		Job steelWorker = new Job(3, 3);
		Job miner = new Job(2, 2);
		Job dishwasher = new Job(4, 0);
		Job dog = new Job(-1, -5);
		
		JobManager jb = new JobManager(true);
		
		jb.offer(stableHand);
		jb.offer(cooking);
		jb.offer(fishing);
		jb.offer(dishwasher);
		jb.offer(miner);
		jb.offer(steelWorker);
		jb.offer(butcher);
		jb.offer(builder);
		jb.offer(dog);
		
		System.out.println("isEmpty 1");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 1");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 1");
		System.out.println(jb.poll());
		System.out.println("         ");
		
		jb.setPriority(false);
		System.out.println("Priority: " + jb.getPriority());
		
		System.out.println("isEmpty 2");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 2");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 2");
		System.out.println(jb.poll());
		System.out.println("         ");
		
		System.out.println("Remaining items: \n" + jb.flush());
		
		jb.setPriority(true);
		System.out.println("Priority: " + jb.getPriority());
		
		System.out.println("\nisEmpty 3");
		System.out.println(jb.isEmpty());
		System.out.println("         ");
		System.out.println("Peak 3");
		System.out.println(jb.peak());
		System.out.println("         ");
		System.out.println("Poll 3");
		System.out.println(jb.poll());
		System.out.println("         ");
	}
}
