package prob2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.PriorityQueue;

public class JobManager {

	PriorityQueue<Job> jobs;
	boolean isPriority;
	
	JobManager(boolean isPriority){
		this.isPriority = isPriority;
		if(this.isPriority) {
			jobs = new PriorityQueue<>(new PriorityComparator());
		}
		else {
			jobs = new PriorityQueue<>(new SecurityComparator());
		}
	}
	
	public void offer(Job job) {
		if(!jobs.contains(job)) {
			jobs.offer(job);
		}
		else {
			System.out.println("This is already in the collection");
		}
	}
	
	public Job peak () {
		return jobs.peek();
	}
	
	public Job poll() {
		return jobs.poll();
	}
	
	public void setPriority(boolean isPriority) {
		this.isPriority = isPriority;
		if(isPriority) {
			PriorityQueue<Job> job = new PriorityQueue<>(new PriorityComparator());
			for(Job j: jobs) {
				job.offer(j);
			}
			jobs = job;
		}
		else {
			PriorityQueue<Job> job = new PriorityQueue<>(new SecurityComparator());
			for(Job j: jobs) {
				job.offer(j);
			}
			jobs = job;
		}
	}
	
	public boolean getPriority() {
		return isPriority;
	}
	
	public boolean isEmpty() {
		if(jobs.size() <= 0) {
			return true;
		}
		return false;
	}
	
	public ArrayList<Job> flush(){
		if(jobs.size() > 0) {
			ArrayList<Job> job = new ArrayList<>(jobs);
			
			jobs.clear();
			
			return job;
		}
		else {
			return null;
		}
	}
}
