package prob2;

import java.util.Comparator;

public class PriorityComparator implements Comparator<Job> {
	
	public int compare(Job j1, Job j2) {
		int comparisionPrio = j2.getPriority() - j1.getPriority();
		
		if(comparisionPrio == 0) {
			return j2.getSecurityLevel() - j1.getSecurityLevel();
		}
		else {
			return comparisionPrio;
		}
	}
}
