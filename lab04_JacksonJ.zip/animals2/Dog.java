package animals2;

public class Dog extends Animal {
	public Dog(String name) {
		super(name);
	}

	public String makeSound() {
		return "Bark";
	}
}

