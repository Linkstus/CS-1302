package animals2;

public interface Flyer {
	public String fly();
}
