package prob1;

public class GoldCheckingAccount extends CheckingAccount{

	
	public GoldCheckingAccount(int id, double balance) {
		super(id, balance);
		// TODO Auto-generated constructor stub
		if(balance < 1000.00) {
			balanceCheck();
			isLowBalance = isLowBalance();
		}
		else {
			isLowBalance = isLowBalance();
		}
	}

	@Override
	public void withdraw(double amt) {
		// TODO Auto-generated method stub
		numWithdrawals++;
		if(balance <= 0) {
			overdraftCharge();
		}
		if(balance < 1000.00) {
			balanceCheck();
		}
			balance -= amt;
		isLowBalance = isLowBalance();
	}

	@Override
	public void endOfMonth() {
		// TODO Auto-generated method stub
		numWithdrawals = 0;
		if(isLowBalance == false || !isLowBalance() ) {
			if(balanceCheck() == 0) {
				interest();
			}
		}
		if(balance < 1000.00 || balanceCheck() != 0) {
			serviceCharge();
		}
	}

	//GCA helper method 1
	@Override
	public void serviceCharge() {
		// TODO Auto-generated method stub
		balance -= 25.00;
	}

	//GCA helper method 2
	public void interest() {
		double temp = balance * .01;
		balance += temp;
	}
	
	//GCA helper method 3
	//keeps track of how many times balance dropped below 1000
	public int balanceCheck() {
		int drop = 0;
		if(balance < 1000.00) {
			drop++;
		}
		return drop;
	}
	
	public String toString() {
		String account = String.format("GCA: id=%d, balance=$%,.2f, isLowBalance=%b, num withdrawals=%d",
				getId(), getBalance(), isLowBalance(), getNumWithdrawals());
		return account;
	}
}
