package prob1;

public class AccountTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//test01();
		//test02();
		//test03();
		//test04();
		test05();
	}
	
	//helper method 1
	//used to generate an id
	public static int generateId() {
		return (int)(Math.random() * 99 + 1);
	}
	
	//test01
	//basic testing to make sure all methods work in Checking account class
	public static void test01() {
		CheckingAccount ca1 = new CheckingAccount(generateId(), 100.00);
		
		System.out.println("Test 01");
		
		System.out.println("getId and getBalance: " + ca1.getId() + " " + ca1.getBalance());
		System.out.println("isLowBalance: " + ca1.isLowBalance());
		System.out.println("numOfWithdrawals: " + ca1.getNumWithdrawals());
		
		ca1.deposit(100000.00);
		ca1.withdraw(25.00);
		ca1.withdraw(100000.00);
		
		System.out.println();
		System.out.println("getId and getBalance: " + ca1.getId() + " " + ca1.getBalance());
		System.out.println("isLowBalance: " + ca1.isLowBalance());
		System.out.println("numOfWithdrawals: " + ca1.getNumWithdrawals());
		
		ca1.withdraw(75);
		
		System.out.println();
		System.out.println("getId and getBalance: " + ca1.getId() + " " + ca1.getBalance());
		System.out.println("isLowBalance: " + ca1.isLowBalance());
		System.out.println("numOfWithdrawals: " + ca1.getNumWithdrawals());
		
		ca1.deposit(122.25);
		
		System.out.println();
		System.out.println("getId and getBalance: " + ca1.getId() + " " + ca1.getBalance());
		System.out.println("isLowBalance: " + ca1.isLowBalance());
		System.out.println("numOfWithdrawals: " + ca1.getNumWithdrawals());
		
		ca1.endOfMonth();
		System.out.println(ca1.toString());
		
		System.out.println();
		
		CheckingAccount ca2 = new CheckingAccount(generateId(), 75.25);
		
		ca2.endOfMonth();
		System.out.println(ca2.toString());
		
		ca2.deposit(50);
		ca2.endOfMonth();
		System.out.println(ca2.toString());
		
	}
	//test 02
	//testing to make sure all goldcheckingaccount methods work
	public static void test02() {
		GoldCheckingAccount gca1 = new GoldCheckingAccount(generateId(), 1000.00);
		
		System.out.println("GoldCheckingAccount info 1: " + gca1.toString());
		
		gca1.deposit(50.20);
		gca1.withdraw(100.50);
		System.out.println("GoldCheckingAccount info 2: " + gca1.toString());
		gca1.withdraw(50.00);
		gca1.withdraw(100.00);
		System.out.println("GoldCheckingAccount info 3: " + gca1.toString());
		gca1.deposit(100.50);
		gca1.withdraw(900.2);
		System.out.println("GoldCheckingAccount info 4: " + gca1.toString());
		gca1.endOfMonth();
		System.out.println(gca1.toString());
		
		gca1.deposit(10000000.00);
		gca1.endOfMonth();
		System.out.println(gca1.toString());
		
		GoldCheckingAccount gca2 = new GoldCheckingAccount(generateId(), 900.00);
		gca2.endOfMonth();
		System.out.println("GCA2: " + gca2.toString());
		gca2.endOfMonth();
		System.out.println("GCA2: " + gca2.toString());
		gca2.withdraw(800.00);
		gca2.endOfMonth();
		System.out.println("GCA2: " + gca2.toString());
		
		GoldCheckingAccount gca3 = new GoldCheckingAccount(generateId(), 1000.00);
		gca3.endOfMonth();
		System.out.println("GCA3: " + gca3.toString());
		
	}
	
	//test03
	//testing negative numbers in the creation of a account and withdraw
	//hope to not crash
	public static void test03() {
		CheckingAccount ca = new CheckingAccount(generateId(), -150.00);
		
		System.out.println(ca.toString());
		
		ca.withdraw(0);
		
		System.out.println(ca.toString());
		
		ca.withdraw(-50.00);
		
		System.out.println(ca.getBalance());
		
		GoldCheckingAccount gca = new GoldCheckingAccount(generateId(), -1000.00);
		
		System.out.println(gca.toString());

		gca.withdraw(0);
		
		System.out.println(gca.toString());
		
		gca.withdraw(-50.00);
		
		System.out.println(gca.getBalance());
	}
	
	//test04
	//testing negative and 0 in deposit method to make sure it does not crash
	public static void test04() {
			CheckingAccount ca = new CheckingAccount(generateId(), -150.00);
			
			System.out.println(ca.toString());
			
			ca.deposit(0);
			
			System.out.println(ca.toString());
			
			ca.deposit(-50.00);
			
			System.out.println(ca.getBalance());
			
			GoldCheckingAccount gca = new GoldCheckingAccount(generateId(), -1000.00);
			
			System.out.println(gca.toString());

			gca.deposit(0);
			
			System.out.println(gca.toString());
			
			gca.deposit(-50.00);
			
			System.out.println(gca.getBalance());
	}
	//test05
	//testing to make sure negative and 0 does not make withdraw crash the code
	public static void test05() {
		CheckingAccount ca = new CheckingAccount(generateId(), 150.00);
		
		System.out.println(ca.toString());
		
		ca.withdraw(0);
		
		System.out.println(ca.toString());
		
		ca.withdraw(-50.00);
		
		System.out.println(ca.getBalance());
		
		GoldCheckingAccount gca = new GoldCheckingAccount(generateId(), 1000.00);
		
		System.out.println(gca.toString());

		gca.withdraw(0);
		
		System.out.println(gca.toString());
		
		gca.withdraw(-50.00);
		
		System.out.println(gca.getBalance());
	}
}
