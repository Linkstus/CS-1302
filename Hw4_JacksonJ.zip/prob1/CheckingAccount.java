package prob1;

public class CheckingAccount {
	protected double balance;
	protected int id;
	protected boolean isLowBalance;
	protected int numWithdrawals;
	
	public CheckingAccount(int id, double balance) {
		this.id = id;
		this.balance = balance;
		if(isLowBalance()) {
			serviceCharge();
			isLowBalance = isLowBalance();
		}
		else{
			isLowBalance = isLowBalance();
		}
	}
		
	public void deposit(double amt){
			balance += amt;
	}
		
	public double getBalance() {
		return balance;
	}
	
	public int getId() {
		return id;
	}
	
	public int getNumWithdrawals() {
		return numWithdrawals;
	}
	
	public boolean isLowBalance() {
		if(isLowBalance == true) {
			return true;
		}
		else {
			return balance < 100.00;
		}
	}
	
	public void withdraw(double amt) {
		numWithdrawals++;
		if(balance <= 0) {
			overdraftCharge();
			isLowBalance = isLowBalance();
		}
		else {
			isLowBalance = isLowBalance();
		}
		 
			balance += amt;
		
		if(numWithdrawals >= 3) {
			withdrawalLimit();
		}
		
	}
	
	public void endOfMonth() {
		numWithdrawals = 0;
		if(isLowBalance == true || isLowBalance()) {
			serviceCharge();
			if(balance <= 0) {
				overdraftCharge();
			}
		}
		if(isLowBalance() == false) {
			isLowBalance = false;
		}
		else {
			isLowBalance = true;
		}
	}
	
	//helper method 1
	public void serviceCharge() {
		balance -= 10.00;
	}
	//helper method 2
	public void overdraftCharge() {
		balance -= 20.00;
	}
	
	public void withdrawalLimit() {
		balance -= 2.00;
	}
	
	public String toString() {
		String account = String.format("CA: id=%d, balance=$%,.2f,isLowBalance=%b, num withdrawals=%d",
				getId(), getBalance(), isLowBalance(), getNumWithdrawals());
		return account;
	}
}
