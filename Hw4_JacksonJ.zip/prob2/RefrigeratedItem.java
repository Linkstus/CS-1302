package prob2;

public class RefrigeratedItem extends Item {
	protected double temp;

	public RefrigeratedItem(String name, double weight, double temp) {
		super(name, weight);
		// TODO Auto-generated constructor stub
		this.temp = temp;
	}
	
	public RefrigeratedItem(Item item, double temp) {
		this(item.getName(), item.getWeight(), temp);
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return (2 * weight + (100 - temp) * 0.1);
	}

	public double getTemp() {
		return temp;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String ri = String.format("name=%s, cost=$%,.2f, weight=%.2f, temp=%.2f degrees", 
				super.getName(), cost(), super.getWeight(), getTemp());
		return ri;
	}
	
}
