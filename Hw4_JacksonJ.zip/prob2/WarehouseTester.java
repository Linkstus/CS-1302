package prob2;

public class WarehouseTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//test01();
		//test02();
		test03();
		//test04();
	}
	
	//helper method 1 to generate a random weight
	public static double randomWeight() {
		return (double)(Math.random() * 99 + 1);
	}
	
	//helper method 2 to generate a random temp
	public static double randomTemp() {
		return (double)(Math.random()* 50 - 30);
	}
	
	//test01
	//test methods in the item class
	public static void test01() {
		Item item1 = new Item("Milk", randomWeight());
		Item item2 = new Item("Water", randomWeight());
		Item item3 = new Item("Milk", randomWeight());
		
		System.out.println(item1.equals(item2));
		System.out.println(item1.equals(item3));
		
		System.out.println(item1.toString());
		System.out.println(item2.toString());
		System.out.println(item3.toString());
	}
	
	//test02
	//testing methods in the Refrigerateditem class
	public static void test02() {
		RefrigeratedItem ri1 = new RefrigeratedItem("Milk", randomWeight(), randomTemp());
		RefrigeratedItem ri2 = new RefrigeratedItem("Milk", randomWeight(), randomTemp());
		RefrigeratedItem ri3 = new RefrigeratedItem("Water", randomWeight(), randomTemp());
		
		System.out.println(ri1.toString());
		
		System.out.println(ri2.equals(ri1));
		System.out.println(ri2.equals(ri3));
		
		System.out.println(ri1.cost());
		
		Item item = new Item("Chocolate", .02);
		RefrigeratedItem r1 = new RefrigeratedItem(item, randomTemp());
		RefrigeratedItem ri4 = new RefrigeratedItem("Chocolate", .02, randomTemp());
		System.out.println(r1.toString());
		System.out.println(ri4.toString());
	}
	
	public static void test03() {
		Warehouse i = new Warehouse();
		Item item1 = new Item("Tomato", randomWeight());
		Item item2 = new Item("Taco Shells", randomWeight());
		Item item3 = new Item("Chocolate", randomWeight());
		Item item4 = new Item("Candy", randomWeight());
		
		RefrigeratedItem ri1 = new RefrigeratedItem("Ice Cream", randomWeight(), randomTemp());
		RefrigeratedItem ri2 = new RefrigeratedItem("Eggs", randomWeight(), randomTemp());
		RefrigeratedItem ri3 = new RefrigeratedItem("Milk", randomWeight(), randomTemp());
		RefrigeratedItem ri4 = new RefrigeratedItem("Water", randomWeight(), randomTemp());
		
		i.addItem(item1);
		i.addItem(item2);
		i.addItem(item3);
		i.addItem(item4);
		i.addItem(ri1);
		i.addItem(ri2);
		i.addItem(ri3);
		i.addItem(ri4);
		
		System.out.println(i.toString());
		
		System.out.println(i.getItem("Milk"));
		System.out.println(i.getItem("Cheese"));
		System.out.println(i.getItem(ri4));
		
		System.out.println(i.getNumItems());
		
		System.out.println(i.getRefrigeratedItems());
		
		System.out.println(i.getTotalCost());
		
		System.out.println(i.getTotalCostRefrigerated());
		
		System.out.println(i.removeItem(ri4));
		
	}
	
	//test04
	//testing each of the classes and methods that are able to accept a number to make sure no error occurs
	public static void test04() {
		Item item = new Item("Milk", -50);
		
		System.out.println(item.toString());
		RefrigeratedItem ri1 = new RefrigeratedItem("Milk", -50, 60);
		RefrigeratedItem ri2 = new RefrigeratedItem("Milk", -50, -60);
		System.out.println(ri1.toString());
		System.out.println(ri2.toString());
	}
	
}
