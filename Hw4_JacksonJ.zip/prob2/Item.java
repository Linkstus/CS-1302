package prob2;

public class Item {
	protected String name;
	protected double weight;
	
	public Item(String name, double weight) {
		this.name = name;
		this.weight = weight;
	}
	
	public double cost() {
		return (weight * 2);
	}
	
	public boolean equals(Object o) {
		Item i = (Item) o;
		return this.getName() == i.getName();
	}
	
	public String getName() {
		return name;
	}
	
	public double getWeight() {
		return weight;
	}

	@Override
	public String toString() {
		String items = String.format("name=%s, cost=$%,.2f, weight=%.2f \n", getName(), cost(), getWeight());
		return items;
	}
}
