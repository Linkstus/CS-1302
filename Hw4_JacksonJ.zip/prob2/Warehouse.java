package prob2;
import java.util.ArrayList;

public class Warehouse {
	protected ArrayList<Item> i = new ArrayList<>();

	public Warehouse() {
	}
	
	public void addItem(Item item) {
		
		i.add(item);
	}
	
	public Item getItem(Item item) {
		int pos = 0;
		if(i.contains(item)) {
			pos = i.indexOf(item);
			return i.get(pos);
		}
		else {
			return null;
		}
	}
	
	public Item getItem(String name) {
		Item dummy = new Item(name, 0.0);
		return getItem(dummy);
	}
	
	public int getNumItems() {
		return i.size();
	}
	
	public ArrayList<RefrigeratedItem> getRefrigeratedItems(){
		ArrayList<RefrigeratedItem> ri = new ArrayList<>();
		for(int j = 0; j < i.size(); j++) {
			if(i.get(j) instanceof RefrigeratedItem) {
				RefrigeratedItem r = (RefrigeratedItem) i.get(j);
				ri.add(r);
			}
		}
		return ri;
	}
	
	public double getTotalCost() {
		double totCost = 0.0;
		for(Item j: i) {
			totCost += j.cost();
		}
		return totCost;
	}
	
	public double getTotalCostRefrigerated() {
		double totCostRefrig = 0.0;
		for(int j = 0; j < i.size(); j++) {
			if(i.get(j) instanceof RefrigeratedItem) {
				RefrigeratedItem r = (RefrigeratedItem) i.get(j);
				totCostRefrig += r.cost();
			}
		}
		return totCostRefrig;
	}
	
	public Item removeItem(Item item) {
		Item temp = new Item("", 0.0);
		int pos = 0;
		if(i.contains(item)) {
			pos = i.indexOf(item);
			temp = i.get(pos);
			i.remove(item);
			return temp;
		}
		else {
			return null;
		}
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		
		for(int j = 0; j < i.size(); j++) {
			if(i.get(j) instanceof RefrigeratedItem) {
				RefrigeratedItem r = (RefrigeratedItem) i.get(j);
				sb.append(r.toString() + "\n");
			}
			else {
				sb.append(i.get(j).toString());
			}
		}
		return sb.toString();
	}
}
