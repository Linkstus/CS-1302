package prob2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class TreeSetProblems {

	public static void main(String[] args) {
		HashSet<Integer> setOne = new HashSet<>();
		setOne.add(1);
		setOne.add(10);
		setOne.add(3);
		setOne.add(38);
		setOne.add(6);
		setOne.add(19);
		setOne.add(-1);
		
		HashSet<Integer> setTwo = new HashSet<>();
		setTwo.add(100);
		setTwo.add(50);
		setTwo.add(29);
		setTwo.add(1000);
		setTwo.add(47);
		setTwo.add(38);
		setTwo.add(300);
		setTwo.add(500);
		setTwo.add(-1000);
		
		System.out.println("Problem 1: ");
		System.out.println("Set before modifications");
		System.out.println(setOne.toString());
		System.out.println("Set after modifications");
		System.out.println(getBig(setOne, 5));
		System.out.println("Original set after modifications: ");
		System.out.println(setOne.toString());
		System.out.println("------------------------------------");
		System.out.println("Problem 1: ");
		System.out.println("Set before modifications");
		System.out.println(setTwo.toString());
		System.out.println("Set after modifications");
		System.out.println(getBig(setTwo, 291));
		System.out.println("Original set after modifications: ");
		System.out.println(setTwo.toString());
		System.out.println("------------------------------------");
	  /*-------------------problem 2------------------------------*/
		
		ArrayList<String> listOne = new ArrayList<>();
		listOne.add("kite");
		listOne.add("ant");
		listOne.add("dog");
		listOne.add("bat");
		listOne.add("apple");
		listOne.add("rat");
		
		ArrayList<Integer> listIntOne = new ArrayList<>();
		listIntOne.add(0);
		listIntOne.add(2);
		listIntOne.add(4);
		
		ArrayList<String> listTwo = new ArrayList<>();
		listTwo.add("Flea");
		listTwo.add("At");
		listTwo.add("Tommorow");
		listTwo.add("cat");
		listTwo.add("bat");
		listTwo.add("hat");
		listTwo.add("poop");
		listTwo.add("rice");
		listTwo.add("headphones");
		
		ArrayList<Integer> listIntTwo = new ArrayList<>();
		listIntTwo.add(0);
		listIntTwo.add(8);
		listIntTwo.add(5);
		listIntTwo.add(5);
		listIntTwo.add(2);
		listIntTwo.add(4);
		
		System.out.println("Problem 2: ");
		System.out.println("Set before modifications");
		System.out.println(listOne.toString());
		System.out.println("Set after modifications");
		System.out.println(getWords(listIntOne, listOne));
		System.out.println("------------------------------------");
		System.out.println("Problem 2: ");
		System.out.println("Set before modifications");
		System.out.println(listTwo.toString());
		System.out.println("Set after modifications");
		System.out.println(getWords(listIntTwo, listTwo));
		System.out.println("------------------------------------");
	  /*-------------------problem 3------------------------------*/
		
		ArrayList<String> listThree = new ArrayList<>();
		listThree.add("Reputation");
		listThree.add("original");
		listThree.add("vigorous");
		listThree.add("Main");
		listThree.add("theorist");
		listThree.add("belt");
		
		ArrayList<Integer> listIntThree = new ArrayList<>();
		listIntThree.add(1);
		listIntThree.add(3);
		listIntThree.add(5);
		
		ArrayList<String> listFour = new ArrayList<>();
		listFour.add("need");
		listFour.add("arise");
		listFour.add("Mars");
		listFour.add("rumor");
		listFour.add("due");
		listFour.add("inhabitant");
		listFour.add("humor");
		listFour.add("citizen");
		listFour.add("deny");
		
		ArrayList<Integer> listIntFour = new ArrayList<>();
		listIntFour.add(5);
		listIntFour.add(8);
		listIntFour.add(1);
		listIntFour.add(6);
		listIntFour.add(3);
		listIntFour.add(5);
		
		System.out.println("Problem 3: ");
		System.out.println("Set before modifications");
		System.out.println(listThree.toString());
		System.out.println("Set after modifications");
		System.out.println(getWords2(listIntThree, listThree));
		System.out.println("Original set after modificiations: ");
		System.out.println(listThree.toString());
		System.out.println("------------------------------------");
		System.out.println("Problem 3: ");
		System.out.println("Set before modifications");
		System.out.println(listFour.toString());
		System.out.println("Set after modifications");
		System.out.println(getWords2(listIntFour, listFour));
		System.out.println("Original set after modificiations: ");
		System.out.println(listFour.toString());
		System.out.println("------------------------------------");
	}
	
	public static TreeSet<Integer> getBig(HashSet<Integer> set, int t){
		Iterator<Integer> big = set.iterator();
		TreeSet<Integer> bigMap = new TreeSet<>();
		
		while(big.hasNext()) {
			int num = big.next();
			if(num > t) {
				bigMap.add(num);
			}
			else {
				big.remove();
			}
		}
		return bigMap;
	}
	
	public static TreeSet<String> getWords(List<Integer> locations, List<String> words){
		TreeSet<String> list = new TreeSet<>();
		
		for(Integer ints: locations) {
			list.add(words.get(ints));
		}
		
		return list;
	}
	
	public static TreeSet<String> getWords2(ArrayList<Integer> locations, ArrayList<String> words){
		TreeSet<String> list = new TreeSet<>();
		
		for(Integer ints: locations) {
			list.add(words.get(ints));
			words.remove(ints);
		}
		return list;
	}
}
