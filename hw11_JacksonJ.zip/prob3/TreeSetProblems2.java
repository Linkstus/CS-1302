package prob3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

public class TreeSetProblems2{

	public static void main(String[] args) {
		LinkedList<Player> players = new LinkedList<>();
		players.add(new Player("James", 23));
		players.add(new Player("Alicia", 43));
		players.add(new Player("Lawson", 12));
		players.add(new Player("Bailey", 5));
		players.add(new Player("David", 44));
		players.add(new Player("Martian", -1));
		
		ArrayList<Player> players2 = new ArrayList<>();
		players2.add(new Player("James", 79));
		players2.add(new Player("Erwin", 515));
		players2.add(new Player("Todor", -569));
		players2.add(new Player("Widukind", 162));
		players2.add(new Player("Samuil", 786));
		players2.add(new Player("Pene", -972));
		players2.add(new Player("Deepika", -569));
		players2.add(new Player("Isadora", 769));
		players2.add(new Player("Janae", -914));
		
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players.toString());
		System.out.println("list after modification: ");
		System.out.println(highRollers(players, 20));
		System.out.println("-----------------------------------");
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players2.toString());
		System.out.println("list after modification: ");
		System.out.println(highRollers(players2, -1));
	  /*---------------problem 2--------------------*/
		
		TreeSet<Player> players3 = new TreeSet<>(new ScoreComparator());
		players3.add(new Player("James", 23));
		players3.add(new Player("Alicia", 43));
		players3.add(new Player("Lawson", 12));
		players3.add(new Player("Bailey", 5));
		players3.add(new Player("David", 44));
		players3.add(new Player("Martian", -1));
		
		TreeSet<Player> players4 = new TreeSet<>(new ScoreComparator());
		players4.add(new Player("James", 79));
		players4.add(new Player("Erwin", 515));
		players4.add(new Player("Todor", -569));
		players4.add(new Player("Widukind", 162));
		players4.add(new Player("Samuil", 786));
		players4.add(new Player("Pene", -972));
		players4.add(new Player("Deepika", -569));
		players4.add(new Player("Isadora", 769));
		players4.add(new Player("Janae", -914));
		
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players3.toString());
		System.out.println("list after modification: ");
		System.out.println(dividePlayers(players3, 20));
		System.out.println("Original list after modifications: ");
		System.out.println(players3.toString());
		System.out.println("-----------------------------------");
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players4.toString());
		System.out.println("list after modification: ");
		System.out.println(dividePlayers(players4, 500));
		System.out.println("Original list after modifications: ");
		System.out.println(players4.toString());
	   /*---------------problem 3--------------------*/
		
		TreeSet<Player> players5 = new TreeSet<>(new ScoreComparator());
		players5.add(new Player("James", 23));
		players5.add(new Player("Alicia", 43));
		players5.add(new Player("Lawson", 12));
		players5.add(new Player("Bailey", 5));
		players5.add(new Player("David", 44));
		players5.add(new Player("Martian", -1));
		
		TreeSet<Player> players6 = new TreeSet<>(new ScoreComparator());
		players6.add(new Player("James", 79));
		players6.add(new Player("Erwin", 515));
		players6.add(new Player("Todor", -569));
		players6.add(new Player("Widukind", 162));
		players6.add(new Player("Samuil", 786));
		players6.add(new Player("Pene", -972));
		players6.add(new Player("Deepika", -569));
		players6.add(new Player("Isadora", 769));
		players6.add(new Player("Janae", -914));
		
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players5.toString());
		System.out.println("list after modification: ");
		System.out.println(getScores(players5));
		System.out.println("-----------------------------------");
		System.out.println("problem 1");
		System.out.println("list before modifications: ");
		System.out.println(players6.toString());
		System.out.println("list after modification: ");
		System.out.println(getScores(players6));
	}
	
	public static TreeSet<Player> highRollers(List<Player> players, int score) {
		TreeSet<Player> tsPlayers = new TreeSet<>(new ScoreComparator());
		Player dummy = new Player("dummy", score);
		
		tsPlayers.addAll(players);
		
		return (TreeSet<Player>) tsPlayers.tailSet(dummy);
	}
	
	public static TreeSet<Player> dividePlayers(TreeSet<Player> player, int thold) {
		TreeSet<Player> tsPlayer = new TreeSet<>(player);
		Player dummy = new Player("dummy", thold-1);
		TreeSet<Player> players = (TreeSet<Player>)tsPlayer.headSet(dummy);
		
		Iterator<Player> loop = player.iterator();
		
		while(loop.hasNext()) {
			Player play = loop.next();
			if(play.getScore() < thold) {
				loop.remove();
			}
		}
		
		return players;
	}
	
	public static TreeSet<Integer> getScores(TreeSet<Player> player){
		TreeSet<Integer> scores = new TreeSet<>();
		
		Iterator<Player> loop = player.iterator();
		
		while(loop.hasNext()) {
			scores.add(loop.next().getScore());
		}
		
		return scores;
	}
}
