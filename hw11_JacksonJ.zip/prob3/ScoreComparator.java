package prob3;

import java.util.Comparator;

public class ScoreComparator implements Comparator<Player>{
	@Override
	public int compare(Player player1, Player player2) {
		int diff = player1.getScore() - player2.getScore();
		if(diff > 0) {
			return 1;
		}
		else if(diff < 0) {
			return -1;
		}
		else {
			return player1.getName().compareTo(player2.getName());
		}
	}

	
}
