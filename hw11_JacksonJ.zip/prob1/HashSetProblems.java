package prob1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class HashSetProblems {

	public static void main(String[] args) {
		//problem 1
		LinkedHashSet<String> lkSet = new LinkedHashSet<>();
		lkSet.add("James");
		lkSet.add("Kayla");
		lkSet.add("Rebecca");
		lkSet.add("Angela");
		lkSet.add("Alicia");
		lkSet.add("Roy");
		lkSet.add("Jackson");
		removeLongNames(lkSet, 5);
		
		LinkedHashSet<String> lkSet2 = new LinkedHashSet<>();
		lkSet2.add("James");
		lkSet2.add("Kayla");
		lkSet2.add("Fish");
		lkSet2.add("Coy");
		lkSet2.add("Danny");
		lkSet2.add("Roy");
		lkSet2.add("Joy");
		removeLongNames(lkSet2, 5);
		
		LinkedHashSet<String> lkSet3 = new LinkedHashSet<>();
		lkSet3.add("James");
		lkSet3.add("Kayla");
		lkSet3.add("Fish");
		lkSet3.add("Coy");
		lkSet3.add("Danny");
		lkSet3.add("Roy");
		lkSet3.add("Joy");
		removeLongNames(lkSet3, 0);
		
		System.out.println("probelm 1: ");
		System.out.println(lkSet);
		System.out.println("--------------------------");
		System.out.println("probelm 1: ");
		System.out.println(lkSet2);
		System.out.println("--------------------------");
		System.out.println("probelm 1: ");
		System.out.println(lkSet3);
		System.out.println("--------------------------");
		System.out.println("problem 2: ");
	//  ------------------problem 2-------------------- \\
		
		LinkedList<String> llnames = new LinkedList<>();
		llnames.add("James");
		llnames.add("Kayla");
		llnames.add("Fish");
		llnames.add("Coy");
		llnames.add("Danny");
		llnames.add("James");
		llnames.add("Roy");
		llnames.add("James");
		llnames.add("Joy");
		ArrayList<String> newList = getUniqueNames(llnames);
		
		LinkedList<String> llnames2 = new LinkedList<>();
		llnames2.add("a");
		llnames2.add("b");
		llnames2.add("a");
		llnames2.add("x");
		llnames2.add("d");
		llnames2.add("A");
		llnames2.add("B");
		llnames2.add("n");
		llnames2.add("e");
		ArrayList<String> newList2 = getUniqueNames(llnames2);
		
		System.out.println("Problem 2: ");
		System.out.println("List before modifications: ");
		System.out.println(llnames.toString());
		System.out.println("List after modifications: ");
		System.out.println(newList.toString());
		System.out.println("--------------------------");
		System.out.println("Problem 2: ");
		System.out.println("List before modifications: ");
		System.out.println(llnames2.toString());
		System.out.println("List after modifications: ");
		System.out.println(newList2.toString());
		System.out.println("--------------------------");
	  //----------------------problem 3------------------//
		
		LinkedHashSet<String> listOne = new LinkedHashSet<>();
		listOne.add("James");
		listOne.add("Kayla");
		listOne.add("Fish");
		listOne.add("Coy");
		listOne.add("Danny");
		listOne.add("James");
		listOne.add("Roy");
		listOne.add("James");
		listOne.add("Joy");
		
		LinkedHashSet<String> listTwo = new LinkedHashSet<>();
		listTwo.add("James");
		listTwo.add("Fish");
		listTwo.add("James");
		listTwo.add("Roy");
		listTwo.add("Anglea");
		listTwo.add("Joy");
		
		LinkedHashSet<String> listThree = new LinkedHashSet<>();
		listThree.add("a");
		listThree.add("b");
		listThree.add("a");
		listThree.add("x");
		listThree.add("d");
		listThree.add("A");
		listThree.add("B");
		listThree.add("n");
		listThree.add("e");
		listThree.add("1");
		listThree.add("/");
		
		LinkedHashSet<String> listFour = new LinkedHashSet<>();
		listFour.add("a");
		listFour.add("a");
		listFour.add("x");
		listFour.add("B");
		listFour.add("n");
		listFour.add("po");
		listFour.add("e");
		
		System.out.println("Problem 3: ");
		System.out.println("Lists before modifications: ");
		System.out.println("SetOne: " + listOne.toString() + "\n" + "SetTwo: " + listTwo.toString());
		System.out.println("List after modifications: ");
		System.out.println(getNamesInCommon(listOne, listTwo));
		System.out.println("--------------------------");
		System.out.println("Problem 3: ");
		System.out.println("List before modifications: ");
		System.out.println("SetThree: " + listThree.toString() + "\n" + "SetFour: " + listFour.toString());
		System.out.println("List after modifications: ");
		System.out.println(getNamesInCommon(listThree, listFour));
		System.out.println("--------------------------");
	  //----------------------problem 4------------------//
		
		LinkedHashSet<String> listOneOne = new LinkedHashSet<>();
		listOneOne.add("James");
		listOneOne.add("Kayla");
		listOneOne.add("Fish");
		listOneOne.add("Coy");
		listOneOne.add("Danny");
		listOneOne.add("James");
		listOneOne.add("Roy");
		listOneOne.add("James");
		listOneOne.add("Joy");
		listOneOne.add("Anglea");
		
		LinkedHashSet<String> listTwoTwo = new LinkedHashSet<>();
		listTwoTwo.add("James");
		listTwoTwo.add("Fish");
		listTwoTwo.add("James");
		listTwoTwo.add("Roy");
		listTwoTwo.add("Joy");
		
		LinkedHashSet<String> listThreeThree = new LinkedHashSet<>();
		listThreeThree.add("a");
		listThreeThree.add("b");
		listThreeThree.add("a");
		listThreeThree.add("x");
		listThreeThree.add("d");
		listThreeThree.add("A");
		listThreeThree.add("B");
		listThreeThree.add("n");
		listThreeThree.add("e");
		listThreeThree.add("1");
		listThreeThree.add("/");
		
		LinkedHashSet<String> listFourFour = new LinkedHashSet<>();
		listFourFour.add("a");
		listFourFour.add("a");
		listFourFour.add("x");
		listFourFour.add("B");
		listFourFour.add("n");
		listFourFour.add("po");
		listFourFour.add("e");
		
		System.out.println("Problem 4: ");
		System.out.println("Lists before modifications: ");
		System.out.println("SetOne: " + listOneOne.toString() + "\n" + "SetTwo: " + listTwoTwo.toString());
		System.out.println("List after modifications: ");
		System.out.println(justInFirst(listOneOne, listTwoTwo));
		System.out.println("--------------------------");
		System.out.println("Problem 4: ");
		System.out.println("List before modifications: ");
		System.out.println("SetThree: " + listThreeThree.toString() + "\n" + "SetFour: " + listFourFour.toString());
		System.out.println("List after modifications: ");
		System.out.println(justInFirst(listThreeThree, listFourFour));
		System.out.println("--------------------------");
	  //---------------------problem 5-------------------//
		
		LinkedList<String> lkSetOne = new LinkedList<>();
		lkSetOne.add("James");
		lkSetOne.add("Kayla");
		lkSetOne.add("Rebecca");
		lkSetOne.add("Angela");
		lkSetOne.add("Alicia");
		lkSetOne.add("Roy");
		lkSetOne.add("Jackson");
		
		LinkedHashSet<String> setOne = new LinkedHashSet<>();
		setOne.add("James");
		setOne.add("Kayla");
		setOne.add("Fish");
		setOne.add("Coy");
		setOne.add("Danny");
		setOne.add("James");
		setOne.add("Roy");
		setOne.add("James");
		setOne.add("Joy");
		setOne.add("Anglea");
		
		LinkedList<String> lkSetTwo = new LinkedList<>();
		lkSetTwo.add("a");
		lkSetTwo.add("b");
		lkSetTwo.add("a");
		lkSetTwo.add("x");
		lkSetTwo.add("d");
		lkSetTwo.add("A");
		lkSetTwo.add("B");
		lkSetTwo.add("n");
		lkSetTwo.add("e");
		
		LinkedHashSet<String> setTwo = new LinkedHashSet<>();
		setTwo.add("b");
		setTwo.add("x");
		setTwo.add("d");
		setTwo.add("e");
		
		System.out.println("Problem 5: ");
		System.out.println("Lists before modifications: ");
		System.out.println("ListOne: " + lkSetOne.toString() + "\n" + "SetOne: " + setOne.toString());
		System.out.println("List after modifications: ");
		System.out.println(getIndicesForMatches(lkSetOne, setOne));
		System.out.println("--------------------------");
		System.out.println("Problem 5: ");
		System.out.println("List before modifications: ");
		System.out.println("ListTwo: " + lkSetTwo.toString() + "\n" + "SetFour: " + setTwo.toString());
		System.out.println("List after modifications: ");
		System.out.println(getIndicesForMatches(lkSetTwo, setTwo));
		System.out.println("--------------------------");
	  /*--------------------problem 6--------------------*/
		
		LinkedHashSet<String> set1 = new LinkedHashSet<>();
		set1.add("James");
		set1.add("Kayla");
		set1.add("Fish");
		set1.add("Coy");
		set1.add("Danny");
		set1.add("James");
		set1.add("Roy");
		set1.add("James");
		set1.add("Joy");
		
		LinkedHashSet<String> set2 = new LinkedHashSet<>();
		set2.add("James");
		set2.add("Fish");
		set2.add("James");
		set2.add("Roy");
		set2.add("Anglea");
		set2.add("Joy");
		
		LinkedHashSet<String> set3 = new LinkedHashSet<>();
		set3.add("a");
		set3.add("b");
		set3.add("a");
		set3.add("x");
		set3.add("d");
		set3.add("A");
		set3.add("B");
		set3.add("n");
		set3.add("e");
		set3.add("1");
		set3.add("/");
		
		LinkedHashSet<String> set4 = new LinkedHashSet<>();
		set4.add("a");
		set4.add("a");
		set4.add("x");
		set4.add("B");
		set4.add("n");
		set4.add("po");
		set4.add("e");
		
		System.out.println("Problem 6: ");
		System.out.println("Lists before modifications: ");
		System.out.println("setOne: " + set1.toString() + "\n" + "setTwo: " + set2.toString());
		System.out.println("List after modifications: ");
		removeDuplicates(set1, set2);
		System.out.println("setOne: " + set1.toString() + "\n" + "setTwo: " + set2.toString());
		System.out.println("--------------------------");
		System.out.println("Problem 6: ");
		System.out.println("Lists before modifications: ");
		System.out.println("setThree: " + set3.toString() + "\n" + "setFour: " + set4.toString());
		System.out.println("List after modifications: ");
		removeDuplicates(set3, set4);
		System.out.println("setThree: " + set3.toString() + "\n" + "setFour: " + set4.toString());
		System.out.println("--------------------------");
	}
	
	//problem 1 chapter 21
	public static void removeLongNames(Set<String> set, int len) {
		Iterator<String> names = set.iterator();
		
		while(names.hasNext()) {
			String name = names.next();
			
			if(name.length() > len) {
				names.remove();
			}
		}
	}
	
	//problem 2 chapter 21
	public static ArrayList<String> getUniqueNames(List<String> name){
		//a list to allow me to modify it
		ArrayList<String> names = new ArrayList<>(name);
		ArrayList<String> uniqueNames = new ArrayList<>();
		int count = 0;
		for(int i = 0; i < names.size() - 1; i++) {
			String temp = names.get(i);
			for(int j = names.size() - 1; j >= i; j--) {
				if(names.get(j).equals(temp)) {
					count++;
				}
			}
			if(count > 1) {
				for(int j = names.size() - 1; j >= i; j--) {
					if(names.get(j).equals(temp)) {
						names.remove(names.get(j));
					}
				}
			}
			count = 0;
		}
		uniqueNames = new ArrayList<>(names);
		return uniqueNames;
	}
	
	//problem 3 chapter 21
	public static Set<String> getNamesInCommon(Set<String> setOne, Set<String> setTwo){
		HashSet<String> commonNames = new HashSet<>(setOne);
		commonNames.retainAll(setTwo);
		return commonNames;
	}
	
	//problem 4 chapter 21
	public static Set<String> justInFirst(Set<String> setOne, Set<String> setTwo){
		HashSet<String> firstList = new HashSet<>(setOne);
		firstList.removeAll(setTwo);
		return firstList;
	}
	
	//problem 5 chapter 21
	public static Set<Integer> getIndicesForMatches(List<String> list, Set<String> set){
		HashSet<Integer> mainSet = new HashSet<>();
		
		Iterator<String> loop = set.iterator();
		
		while(loop.hasNext()) {
			String character = loop.next();
			for(int i = 0; i < list.size(); i++) {
				if(character.equals(list.get(i))) {
					mainSet.add(i);
				}
			}
		}
		return mainSet;
	}
	
	//problem 6 chapter 21
	public static void removeDuplicates(Set<String> setOne, Set<String> setTwo) {
		HashSet<String> tempSet1 = new HashSet<>(setOne);
		HashSet<String> tempSet2 = new HashSet<>(setTwo);
		setOne.removeAll(tempSet2);
		setTwo.removeAll(tempSet1);
	}
}
