package prob1;

import emps.Employee;

public class StoreTester {
	
	public static void main(String[] args) {
		Test01();
		Test02();
		Test03();
		Test04();
		Test05();
	}
	//creates a random name from a array of names
	//helper method 1
	public static String createEmpName() {
		String[] names = {"Waldo", "Charlie", "Random", "Alpha", "Heather", "Tester", "Steve", "James",
				"Alicia", "David", "Cody", "Matthew", "Bailey", "Christian", "Jobs", "Todd", "Caleb",
				"Greg", "Melinda", "Patrick", "Jerry", "Nathaniel", "Alex", "Richard", "Dawn", "Floyd",
				"Bod", "Ernie", "Rober", "John", "Henry", "Edgar", "Allen", "Lee", "Homer", "Brenda",
				"Natasha", "Marco", "Pollo", "Spencer", "Anglea", "Kayla", "Rebbeca", "Ronnie", "Kim", 
				"Sharon", "Horus", "Cole", "Alber", "Kenny"};
		
		return names[(int)(Math.random()*49)];
	}
	
	//generates a random wage for the employee
	//helper method 2
	public static double createEmpPay() {
		return (double)(Math.random() * 15);
		
	}
	
	//generates random numbers for employees hours
	//helper method 3
	public static double createEmpHrs() {
		return (double)(Math.random() * 12);
	}
	
	//regular testing 
	public static void Test01() {
		//creates 20 employees
		Employee[] emps = new Employee[20];
		//creates a new store for testing
		Store s = new Store();
		//loops through to fill in an array of employees and adding them to the object array
		for(int i = 0; i < emps.length; i++) {
			emps[i] = new Employee(createEmpName(), createEmpPay());
			s.addEmp(emps[i]);
			//sets the hours for that employee just created
			emps[i].setHours(0, createEmpHrs());
			emps[i].setHours(1, createEmpHrs());
			emps[i].setHours(2, createEmpHrs());
			emps[i].setHours(3, createEmpHrs());
			emps[i].setHours(4, createEmpHrs());
			emps[i].setHours(5, createEmpHrs());
			emps[i].setHours(6, createEmpHrs());
		}
		System.out.println("Test01");
		//test to make the the toString method works
		System.out.println(s.toString());
		
		//test to make sure all employees where truly added to the store
		System.out.println("Number of employees: " + s.getNumEmps());
		
		//sees if there which employee is where 
		System.out.println("Pulls an employee folder of: " + s.getEmp(10));
		System.out.println("Pulls an employee folder of: " + s.getEmp(0));
		System.out.println("Pulls an employee folder of: " + s.getEmp(20));
		
	}
	
	//testing to see if adding a employee to a full store will "crash" the code
	public static void Test02() {
		//creates 20 employees
		Employee[] emps = new Employee[20];
		//creates a new store for testing
		Store s = new Store();
		//loops through to fill in an array of employees and adding them to the object array
		for(int i = 0; i < emps.length; i++) {
			emps[i] = new Employee(createEmpName(), createEmpPay());
			s.addEmp(emps[i]);
			//sets the hours for that employee just created
			emps[i].setHours(0, createEmpHrs());
			emps[i].setHours(1, createEmpHrs());
			emps[i].setHours(2, createEmpHrs());
			emps[i].setHours(3, createEmpHrs());
			emps[i].setHours(4, createEmpHrs());
			emps[i].setHours(5, createEmpHrs());
			emps[i].setHours(6, createEmpHrs());
			//to stop the loop at 19 to test the addEmp method
			if(i == 18)
				break;
		}
		System.out.println("Test02");
		//test to see if adding an employee to the 20th place
		Employee e = new Employee("Zebra", 25.00);
		s.addEmp(e);
		
		//seeing if an out-of-Bounds occurs from adding to the 21st place
		Employee e1 = new Employee("Dog", 10.00);
		s.addEmp(e1);
		
		System.out.println(s.toString());
	}
	//checking the getter for emp does not screw up when out of bounds
	public static void Test03() {
		//creates 20 employees
		Employee[] emps = new Employee[20];
		//creates a new store for testing
		Store s = new Store();
		//loops through to fill in an array of employees and adding them to the object array
		for(int i = 0; i < emps.length; i++) {
			emps[i] = new Employee(createEmpName(), createEmpPay());
			s.addEmp(emps[i]);
			//sets the hours for that employee just created
			emps[i].setHours(0, createEmpHrs());
			emps[i].setHours(1, createEmpHrs());
			emps[i].setHours(2, createEmpHrs());
			emps[i].setHours(3, createEmpHrs());
			emps[i].setHours(4, createEmpHrs());
			emps[i].setHours(5, createEmpHrs());
			emps[i].setHours(6, createEmpHrs());
		}
		System.out.println("Test03");
		//test the getEmp to see what returns
		System.out.println(s.getEmp(2));
		System.out.println("\n" + s.getEmp(0));
		//test for the extreme out-of-bounds error
		System.out.println("\n" + s.getEmp(22));
		//test for the lowest out-of-bounds error
		System.out.println("\n" + s.getEmp(-1));
	}
	
	//removing employees to see if even after out-of-bounds it does not fail
	public static void Test04() {
		//creates 20 employees
		Employee[] emps = new Employee[20];
		//creates a new store for testing
		Store s = new Store();
		//loops through to fill in an array of employees and adding them to the object array
		for(int i = 0; i < emps.length; i++) {
			emps[i] = new Employee(createEmpName(), createEmpPay());
			s.addEmp(emps[i]);
			//sets the hours for that employee just created
			emps[i].setHours(0, createEmpHrs());
			emps[i].setHours(1, createEmpHrs());
			emps[i].setHours(2, createEmpHrs());
			emps[i].setHours(3, createEmpHrs());
			emps[i].setHours(4, createEmpHrs());
			emps[i].setHours(5, createEmpHrs());
			emps[i].setHours(6, createEmpHrs());
		}
		System.out.println("Test04");
		//test the removing of someone
		System.out.println("Removing employee 19");
		System.out.println(s.removeEmployee(19) + "\n");
		
		//test if the removing of someone will return null or error
		System.out.println("Removing employee 20. Should report null!");
		System.out.println(s.removeEmployee(20) + "\n");
		
		//testing the lowest out-of-bounds error
		System.out.println("Removing employee -1. Should report null!");
		System.out.println(s.removeEmployee(-1) + "\n");
		
		
		System.out.println("Removing employee 5");
		System.out.println(s.removeEmployee(5) + "\n");
		
		//making sure they are removed
		System.out.println(s.toString());
	}
	
	//Testing to see what happens when an employee has negative hours
	public static void Test05() {
		//creates 20 employees
		Employee[] emps = new Employee[20];
		//creates a new store for testing
		Store s = new Store();
		//loops through to fill in an array of employees and adding them to the object array
		for(int i = 0; i < emps.length; i++) {
			emps[i] = new Employee(createEmpName(), createEmpPay());
			s.addEmp(emps[i]);
			//sets the hours for that employee just created
			emps[i].setHours(0, createEmpHrs());
			emps[i].setHours(1, createEmpHrs());
			emps[i].setHours(2, createEmpHrs());
			emps[i].setHours(3, createEmpHrs());
			emps[i].setHours(4, createEmpHrs());
			emps[i].setHours(5, createEmpHrs());
			emps[i].setHours(6, -5);
		}
		System.out.println("Test05");
		//testing to see if there is an error in the code when a negative hour is put in
		System.out.println(s.getTotalHours());
		System.out.println(s.getEmp(0));
	}	
}
