package prob1;

import emps.Employee;

public class Store {
	private Employee[] emps = new Employee[20];
	private int numEmps = 0;
	
	public Store() {
	}
	
	public void addEmp(Employee e) {
		if(numEmps >= 20 || numEmps < 0) {
		}
		else
			emps[numEmps++] = e;
	}
	
	public Employee getEmp(int i) {
		if(i < numEmps && i >= 0)
			return emps[i];
		else
			return null;
	}
	
	public int getNumEmps() {
		return numEmps;
	}
	
	public double getTotalHours() {
		double totHours = 0.0;
		for(int i = 0; i < numEmps; i++) {
			totHours += emps[i].getTotalHours();
		}
		return totHours;
	}
	
	public double getTotalPay() {
		double totPay = 0.0;
		for(int i = 0; i < numEmps; i++) {
			totPay += emps[i].getPay();
		}
		return totPay;
	}
	
	public Employee removeEmployee(int i) {
		Employee temp = new Employee("", 0.0);
		if(i < numEmps && i >= 0) {
			if(emps[i] != null) {
				temp = emps[i];
			}
			for(int j = i; j < numEmps - 1; j++) {
				emps[j] = emps[j+1];
			}
			numEmps --;
			return temp;
		}
		else
			return null;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Payroll Report\n\n");
		sb.append(String.format("Num Employees:%d, total hrs:%.2f, total pay=$%,.2f\n\n", getNumEmps(), getTotalHours(), getTotalPay()));
		
		for(int i = 0; i < numEmps; i++) {
			sb.append(emps[i].toString() + "\n\n");
		}
		
		return sb.toString();
	}

	/*public static void main(String[] args) {
		//Employee e = new Employee("Will", 22.33);
		Store s = new Store();
		s.addEmp(new Employee("a",10.0));
		Employee e = s.getEmp(0);
		int numEmps = s.getNumEmps();
		double totHours = s.getTotalHours();
		double totPay = s.getTotalPay();
		Employee e2 = s.removeEmployee(0);
		String str = s.toString();

	}*/
}
